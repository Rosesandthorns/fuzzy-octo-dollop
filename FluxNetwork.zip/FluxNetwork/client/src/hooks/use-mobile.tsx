import * as React from "react"

const MOBILE_BREAKPOINT = 768

export function useIsMobile() {
  // Initialize with reasonable default (true on small screens, false on larger screens)
  const [isMobile, setIsMobile] = React.useState<boolean>(
    typeof window !== 'undefined' ? window.innerWidth < MOBILE_BREAKPOINT : false
  )

  React.useEffect(() => {
    // Function to update the state based on window size
    const updateSize = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    }

    // Set up event listener
    window.addEventListener('resize', updateSize)
    
    // Call once on mount to ensure correct initial state
    updateSize()

    // Clean up the listener
    return () => window.removeEventListener('resize', updateSize)
  }, [])

  // Also check user agent string for mobile devices
  React.useEffect(() => {
    if (typeof window !== 'undefined' && typeof navigator !== 'undefined') {
      const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera || ''
      const mobileRegex = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i
      
      if (mobileRegex.test(userAgent.toLowerCase())) {
        setIsMobile(true)
      }
    }
  }, [])

  return isMobile
}
