import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface TeamMember {
  id: string;
  initials: string;
  color: string;
}

interface StatusCardProps {
  status: {
    isOperational: boolean;
    updatedAgo: string;
    storagePercentage: number;
    activeMembers: number;
    totalMembers: number;
    teamMembers: TeamMember[];
  };
}

export function StatusCard({ status }: StatusCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>System Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div 
                className={`h-3 w-3 rounded-full mr-2 ${
                  status.isOperational ? "bg-green-500" : "bg-red-500"
                }`}
              ></div>
              <span className="text-sm">
                {status.isOperational ? "All services operational" : "Some services are down"}
              </span>
            </div>
            <span className="text-xs text-muted-foreground">Updated {status.updatedAgo}</span>
          </div>
          
          <Progress value={status.storagePercentage} className="h-2.5" />
          <div className="text-xs text-right text-muted-foreground">
            Storage: {status.storagePercentage}% available
          </div>
          
          <div className="border-t border-border pt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Active Team Members</span>
              <span className="text-sm font-medium text-primary">
                {status.activeMembers}/{status.totalMembers}
              </span>
            </div>
            <div className="flex -space-x-2 overflow-hidden">
              {status.teamMembers.map((member) => (
                <div 
                  key={member.id}
                  className="inline-block h-6 w-6 rounded-full ring-2 ring-background flex items-center justify-center text-xs text-white"
                  style={{ backgroundColor: `var(--${member.color})` }}
                >
                  {member.initials}
                </div>
              ))}
              {status.activeMembers > status.teamMembers.length && (
                <div className="inline-block h-6 w-6 rounded-full ring-2 ring-background bg-muted flex items-center justify-center text-xs">
                  +{status.activeMembers - status.teamMembers.length}
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
