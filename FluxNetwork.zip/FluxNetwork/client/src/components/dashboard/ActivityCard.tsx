import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Activity {
  id: string;
  type: "message" | "meeting" | "notification";
  title: string;
  time: string;
  icon: string;
}

interface ActivityCardProps {
  activities: Activity[];
}

export function ActivityCard({ activities }: ActivityCardProps) {
  const getIconClassName = (type: Activity["type"]) => {
    switch (type) {
      case "message":
        return "ri-message-2-line";
      case "meeting":
        return "ri-team-line";
      case "notification":
        return "ri-notification-3-line";
      default:
        return "ri-notification-3-line";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 rounded-full bg-background flex items-center justify-center">
                  <i className={`${getIconClassName(activity.type)} text-primary`}></i>
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium">{activity.title}</p>
                <p className="text-xs text-muted-foreground">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
