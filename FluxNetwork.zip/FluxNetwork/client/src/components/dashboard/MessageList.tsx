import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Message {
  id: string;
  sender: {
    name: string;
    initials: string;
    color: string;
  };
  content: string;
  time: string;
  isNew?: boolean;
}

interface MessageListProps {
  messages: Message[];
  onMessageClick: (messageId: string) => void;
}

export function MessageList({ messages, onMessageClick }: MessageListProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Messages</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ul className="divide-y divide-border">
          {messages.map((message) => (
            <li
              key={message.id}
              className="px-6 py-4 flex items-center justify-between hover:bg-muted/50 cursor-pointer transition-colors"
              onClick={() => onMessageClick(message.id)}
            >
              <div className="flex items-center">
                <div 
                  className="h-10 w-10 rounded-full flex items-center justify-center text-white font-medium"
                  style={{ backgroundColor: `var(--${message.sender.color})` }}
                >
                  {message.sender.initials}
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium">{message.sender.name}</p>
                  <p className="text-xs truncate max-w-xs text-muted-foreground">
                    {message.content}
                  </p>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <span className="text-xs text-muted-foreground">{message.time}</span>
                {message.isNew && (
                  <Badge className="mt-1" variant="default">New</Badge>
                )}
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
