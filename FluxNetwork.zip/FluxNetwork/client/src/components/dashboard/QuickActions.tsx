import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface Action {
  id: string;
  label: string;
  icon: string;
  isPrimary?: boolean;
  onClick: () => void;
}

interface QuickActionsProps {
  actions: Action[];
}

export function QuickActions({ actions }: QuickActionsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {actions.map((action) => (
            <Button
              key={action.id}
              variant={action.isPrimary ? "default" : "outline"}
              className="w-full flex items-center justify-start"
              onClick={action.onClick}
            >
              <i className={`${action.icon} mr-2 text-lg`}></i>
              {action.label}
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
