import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { signOut } from "@/lib/auth";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";

export function Navbar() {
  const { user, hasCompletedProfile } = useAuth();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(true);

  const toggleDarkMode = () => {
    document.documentElement.classList.toggle("dark");
    document.documentElement.classList.toggle("light");
    setDarkMode(!darkMode);
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: "Signed out",
        description: "You have been successfully signed out.",
      });
    } catch (error) {
      toast({
        title: "Sign out failed",
        description: "Could not sign out. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsMobileMenuOpen(false);
    }
  };

  const getInitials = (name: string | null) => {
    if (!name) return "U";
    const parts = name.split(" ");
    if (parts.length > 1) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <nav className="bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/">
              <a className="flex-shrink-0 flex items-center">
                <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center">
                  <i className="ri-flashlight-fill text-white text-xl"></i>
                </div>
                <span className="ml-2 text-xl font-semibold text-primary">Flux</span>
              </a>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-8">
            <Link href="/">
              <a className="px-3 py-2 text-sm font-medium text-primary border-b-2 border-primary">Home</a>
            </Link>
            <Link href="/features">
              <a className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Features</a>
            </Link>
            <Link href="/pricing">
              <a className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Pricing</a>
            </Link>
            <Link href="/support">
              <a className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Support</a>
            </Link>
          </div>
          
          {/* Auth Buttons / User Menu */}
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleDarkMode}
              className="rounded-full focus:ring-primary"
            >
              <i className="ri-contrast-2-line text-xl"></i>
            </Button>
            
            {!user && (
              <div className="auth-buttons flex space-x-4 ml-4">
                <Link href="/login">
                  <Button>Sign in</Button>
                </Link>
                <Link href="/login">
                  <Button variant="outline">Register</Button>
                </Link>
              </div>
            )}
            
            {user && hasCompletedProfile && (
              <div className="relative ml-3">
                <div className="flex items-center gap-2">
                  {user.displayName && (
                    <span className="text-sm font-medium hidden md:block">
                      {user.displayName}
                    </span>
                  )}
                  <Button variant="ghost" className="rounded-full p-0 h-8 w-8 overflow-hidden">
                    {user.photoURL ? (
                      <img 
                        src={user.photoURL} 
                        alt={user.displayName || "User"} 
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="h-full w-full bg-secondary flex items-center justify-center text-white">
                        {getInitials(user.displayName)}
                      </div>
                    )}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={handleSignOut}>
                    <i className="ri-logout-box-line text-lg"></i>
                  </Button>
                </div>
              </div>
            )}
          </div>
          
          {/* Mobile menu button */}
          <div className="flex items-center sm:hidden">
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full mr-2" 
              onClick={toggleDarkMode}
            >
              <i className="ri-contrast-2-line text-xl"></i>
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-expanded={isMobileMenuOpen}
            >
              <i className="ri-menu-line text-xl"></i>
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link href="/">
              <a className="block px-3 py-2 text-base font-medium text-primary border-l-4 border-primary">Home</a>
            </Link>
            <Link href="/features">
              <a className="block px-3 py-2 text-base font-medium text-muted-foreground hover:text-primary hover:border-l-4 hover:border-primary transition-colors">Features</a>
            </Link>
            <Link href="/pricing">
              <a className="block px-3 py-2 text-base font-medium text-muted-foreground hover:text-primary hover:border-l-4 hover:border-primary transition-colors">Pricing</a>
            </Link>
            <Link href="/support">
              <a className="block px-3 py-2 text-base font-medium text-muted-foreground hover:text-primary hover:border-l-4 hover:border-primary transition-colors">Support</a>
            </Link>
          </div>
          
          {user && hasCompletedProfile && (
            <div className="pt-4 pb-3 border-t border-border">
              <div className="flex items-center px-4">
                <div className="flex-shrink-0">
                  {user.photoURL ? (
                    <img 
                      src={user.photoURL} 
                      alt={user.displayName || "User"} 
                      className="h-10 w-10 rounded-full"
                    />
                  ) : (
                    <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center text-white font-medium">
                      {getInitials(user.displayName)}
                    </div>
                  )}
                </div>
                <div className="ml-3">
                  <div className="text-base font-medium">{user.displayName}</div>
                  <div className="text-sm font-medium text-muted-foreground">{user.email}</div>
                </div>
              </div>
              <div className="mt-3 space-y-1">
                <Button 
                  variant="ghost" 
                  className="w-full justify-start px-4 py-2 text-base font-medium"
                  onClick={handleSignOut}
                >
                  Sign out
                </Button>
              </div>
            </div>
          )}
          
          {!user && (
            <div className="pt-4 pb-3 border-t border-border px-4 space-y-2">
              <Link href="/login">
                <Button className="w-full">Sign in</Button>
              </Link>
              <Link href="/login">
                <Button variant="outline" className="w-full">Register</Button>
              </Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}
