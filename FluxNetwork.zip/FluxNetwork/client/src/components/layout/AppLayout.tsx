import { ReactNode, useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import { 
  Users, 
  MessageSquare, 
  Grid3X3, 
  ChevronDown, 
  Settings, 
  LogOut, 
  PlusCircle,
  Bell,
  User,
  Menu,
  X
} from "lucide-react";
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from "@/components/ui/tooltip";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { signOut, getFriends, Friend } from "@/lib/auth";

interface AppLayoutProps {
  children: ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  const { user, userProfile } = useAuth();
  const [location] = useLocation();
  const [roomsExpanded, setRoomsExpanded] = useState(true);
  const [friendsExpanded, setFriendsExpanded] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const isMobile = useIsMobile();

  // User data
  const avatarUrl = userProfile?.avatarUrl || "";
  const displayName = userProfile?.displayName || user?.displayName || "User";
  const username = userProfile?.username || "user";

  // Rooms data - will be loaded from API in future
  const [rooms, setRooms] = useState<{id: string; name: string; unread: number}[]>([]);
  
  // Friends data - will be loaded from Firestore
  const [friends, setFriends] = useState<{id: string; name: string; status: string; unread: number}[]>([]);
  
  // Load actual friends data
  useEffect(() => {
    const loadFriendsData = async () => {
      if (!user) return;
      
      try {
        // Get friends from Firebase
        const friendsData = await getFriends(user.uid);
        
        // Map to the format needed by sidebar
        const formattedFriends = friendsData.map((friend: Friend) => ({
          id: friend.id,
          name: friend.displayName,
          status: friend.status,
          unread: 0 // We don't track unread counts yet
        }));
        
        setFriends(formattedFriends);
      } catch (error) {
        console.error("Error loading friends for sidebar:", error);
      }
    };
    
    loadFriendsData();
  }, [user]);

  const handleLogout = async () => {
    await signOut();
  };

  // Close sidebar when layout changes to mobile
  useEffect(() => {
    if (isMobile) {
      setSidebarOpen(false);
    }
  }, [isMobile]);

  return (
    <div className="h-screen flex flex-col bg-background text-foreground">
      {/* App Header */}
      <header className="h-14 border-b border-border flex items-center justify-between px-4 py-2 bg-card">
        <div className="flex items-center">
          {isMobile && (
            <Button 
              variant="ghost" 
              size="icon" 
              className="mr-2"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          )}
          <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center mr-2">
            <span className="text-white font-bold">F</span>
          </div>
          <h1 className="text-xl font-bold">Flux</h1>
        </div>
        <div className="flex items-center space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  <span className="absolute top-1 right-1 h-2 w-2 bg-destructive rounded-full"></span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Notifications</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                <Avatar className="h-9 w-9">
                  <AvatarImage src={avatarUrl} />
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    {displayName.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuLabel>
                <div className="flex flex-col space-y-1">
                  <p className="font-medium text-sm">{displayName}</p>
                  <p className="text-xs text-muted-foreground">@{username}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuGroup>
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/account">
                    <div className="flex items-center cursor-pointer w-full">
                      <User className="mr-2 h-4 w-4" />
                      <span>Account</span>
                    </div>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/settings">
                    <div className="flex items-center cursor-pointer w-full">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </div>
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuGroup>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* App Sidebar - Hidden on mobile unless sidebarOpen is true */}
        {(!isMobile || sidebarOpen) && (
          <aside 
            className={cn(
              "border-r border-border bg-card overflow-y-auto",
              isMobile 
                ? "fixed top-14 bottom-0 z-50 w-60" 
                : "w-60 flex-shrink-0"
            )}
          >
            <div className="p-3">
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <button 
                    onClick={() => setRoomsExpanded(!roomsExpanded)}
                    className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground"
                  >
                    <ChevronDown className={cn(
                      "h-4 w-4 mr-1 transition-transform",
                      roomsExpanded ? "" : "-rotate-90"
                    )} />
                    Rooms
                  </button>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Link href="/dashboard/create-room">
                          <Button variant="ghost" size="icon" className="h-6 w-6">
                            <PlusCircle className="h-4 w-4" />
                          </Button>
                        </Link>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Create Room</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                
                {roomsExpanded && (
                  <div className="space-y-1">
                    {rooms.map(room => (
                      <Link 
                        key={room.id} 
                        href={`/dashboard/room/${room.id}`}
                        onClick={() => isMobile && setSidebarOpen(false)}
                      >
                        <div className={cn(
                          "flex items-center justify-between rounded-md px-3 py-2 cursor-pointer text-sm",
                          location === `/dashboard/room/${room.id}` 
                            ? "bg-accent text-accent-foreground" 
                            : "hover:bg-muted"
                        )}>
                          <span>{room.name}</span>
                          {room.unread > 0 && (
                            <span className="bg-primary text-primary-foreground h-5 w-5 rounded-full flex items-center justify-center text-xs">
                              {room.unread}
                            </span>
                          )}
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <button 
                    onClick={() => setFriendsExpanded(!friendsExpanded)}
                    className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground"
                  >
                    <ChevronDown className={cn(
                      "h-4 w-4 mr-1 transition-transform",
                      friendsExpanded ? "" : "-rotate-90"
                    )} />
                    Friends
                  </button>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Link href="/dashboard/add-friend">
                          <Button variant="ghost" size="icon" className="h-6 w-6">
                            <PlusCircle className="h-4 w-4" />
                          </Button>
                        </Link>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Add Friend</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                
                {friendsExpanded && (
                  <div className="space-y-1">
                    {friends.map(friend => (
                      <Link 
                        key={friend.id} 
                        href={`/dashboard/chat/${friend.id}`}
                        onClick={() => isMobile && setSidebarOpen(false)}
                      >
                        <div className={cn(
                          "flex items-center justify-between rounded-md px-3 py-2 cursor-pointer text-sm",
                          location === `/dashboard/chat/${friend.id}` 
                            ? "bg-accent text-accent-foreground" 
                            : "hover:bg-muted"
                        )}>
                          <div className="flex items-center">
                            <div className={cn(
                              "h-2 w-2 rounded-full mr-2",
                              friend.status === "online" ? "bg-green-500" :
                              friend.status === "idle" ? "bg-yellow-500" : "bg-gray-500"
                            )} />
                            <span>{friend.name}</span>
                          </div>
                          {friend.unread > 0 && (
                            <span className="bg-primary text-primary-foreground h-5 w-5 rounded-full flex items-center justify-center text-xs">
                              {friend.unread}
                            </span>
                          )}
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </aside>
        )}

        {/* Navigation Tabs - Hidden on mobile when sidebar is open */}
        {(!isMobile || !sidebarOpen) && (
          <nav className={cn(
            "flex-shrink-0 border-r border-border bg-card",
            isMobile ? "w-full" : "w-16"
          )}>
            <div className={cn(
              "flex py-4",
              isMobile ? "flex-row justify-around space-y-0" : "flex-col items-center space-y-4"
            )}>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Link href="/dashboard">
                      <Button 
                        variant={location === "/dashboard" ? "default" : "ghost"} 
                        size="icon"
                        className="h-10 w-10 rounded-md"
                      >
                        <Grid3X3 className="h-5 w-5" />
                      </Button>
                    </Link>
                  </TooltipTrigger>
                  <TooltipContent side={isMobile ? "bottom" : "right"}>
                    <p>Dashboard</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Link href="/dashboard/messages">
                      <Button 
                        variant={location === "/dashboard/messages" ? "default" : "ghost"}
                        size="icon"
                        className="h-10 w-10 rounded-md"
                      >
                        <MessageSquare className="h-5 w-5" />
                      </Button>
                    </Link>
                  </TooltipTrigger>
                  <TooltipContent side={isMobile ? "bottom" : "right"}>
                    <p>Messages</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Link href="/dashboard/friends">
                      <Button 
                        variant={location === "/dashboard/friends" ? "default" : "ghost"}
                        size="icon"
                        className="h-10 w-10 rounded-md"
                      >
                        <Users className="h-5 w-5" />
                      </Button>
                    </Link>
                  </TooltipTrigger>
                  <TooltipContent side={isMobile ? "bottom" : "right"}>
                    <p>Friends</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Link href="/dashboard/settings">
                      <Button 
                        variant={location === "/dashboard/settings" ? "default" : "ghost"}
                        size="icon"
                        className="h-10 w-10 rounded-md"
                      >
                        <Settings className="h-5 w-5" />
                      </Button>
                    </Link>
                  </TooltipTrigger>
                  <TooltipContent side={isMobile ? "bottom" : "right"}>
                    <p>Settings</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </nav>
        )}

        {/* Main Content Area */}
        <main className="flex-1 overflow-auto bg-background">
          {children}
        </main>
      </div>

      {/* Modal backdrop for mobile */}
      {isMobile && sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        />
      )}
    </div>
  );
}