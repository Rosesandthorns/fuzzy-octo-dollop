import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { signOut } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: "Signed out",
        description: "You have been successfully signed out.",
      });
    } catch (error) {
      toast({
        title: "Sign out failed",
        description: "Could not sign out. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getInitials = (name: string | null) => {
    if (!name) return "U";
    const parts = name.split(" ");
    if (parts.length > 1) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  const navigation = [
    { name: "Home", href: "/dashboard", icon: "ri-home-5-line" },
    { name: "Messages", href: "/messages", icon: "ri-message-3-line" },
    { name: "Teams", href: "/teams", icon: "ri-team-line" },
    { name: "Events", href: "/events", icon: "ri-calendar-event-line" },
    { name: "Settings", href: "/settings", icon: "ri-settings-5-line" },
  ];

  return (
    <div className="flex flex-col w-64 h-full bg-sidebar">
      <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto">
        <div className="flex items-center flex-shrink-0 px-4 mb-5">
          <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center">
            <i className="ri-flashlight-fill text-white text-xl"></i>
          </div>
          <span className="ml-2 text-xl font-semibold text-primary">Flux</span>
        </div>
        <div className="mt-5 flex-grow flex flex-col">
          <nav className="flex-1 px-2 space-y-1">
            {navigation.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.name} href={item.href}>
                  <a
                    className={cn(
                      "group flex items-center px-3 py-2 text-sm font-medium rounded-md",
                      isActive
                        ? "bg-primary text-white"
                        : "text-sidebar-foreground hover:bg-sidebar-accent"
                    )}
                  >
                    <i className={`${item.icon} text-xl mr-3 ${isActive ? "" : "opacity-75"}`}></i>
                    {item.name}
                  </a>
                </Link>
              );
            })}
          </nav>
        </div>
        
        {/* User Profile Section */}
        {user && (
          <div className="flex-shrink-0 flex border-t border-sidebar-border p-4">
            <div className="flex-shrink-0 w-full group block">
              <div className="flex items-center">
                <div>
                  {user.photoURL ? (
                    <img 
                      src={user.photoURL} 
                      alt={user.displayName || "User"} 
                      className="h-9 w-9 rounded-full"
                    />
                  ) : (
                    <div className="h-9 w-9 rounded-full bg-secondary flex items-center justify-center text-white font-medium">
                      {getInitials(user.displayName)}
                    </div>
                  )}
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-sidebar-foreground">
                    {user.displayName || "User"}
                  </p>
                  <p className="text-xs font-medium text-sidebar-foreground opacity-75">
                    @{user.email?.split('@')[0] || "user"}
                  </p>
                </div>
                <div className="ml-auto">
                  <button 
                    className="text-sidebar-foreground opacity-75 hover:text-primary transition-colors"
                    onClick={handleSignOut}
                  >
                    <i className="ri-logout-box-line text-lg"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
