import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-muted/30 border-t border-border">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          <div className="space-y-8 xl:col-span-1">
            <div className="flex items-center">
              <div className="h-10 w-10 bg-primary rounded-md flex items-center justify-center">
                <i className="ri-flashlight-fill text-white text-2xl"></i>
              </div>
              <span className="ml-3 text-2xl font-bold text-primary">Flux</span>
            </div>
            <p className="text-muted-foreground text-base">
              The Discord alternative that respects your privacy and your wallet.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-muted-foreground hover:text-primary">
                <span className="sr-only">Twitter</span>
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary">
                <span className="sr-only">GitHub</span>
                <i className="ri-github-fill text-xl"></i>
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary">
                <span className="sr-only">Discord</span>
                <i className="ri-discord-fill text-xl"></i>
              </a>
            </div>
          </div>
          
          <div className="mt-12 grid grid-cols-2 gap-8 xl:mt-0 xl:col-span-2">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-foreground tracking-wider uppercase">
                  Product
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/features">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        Features
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/pricing">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        Pricing
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/changelog">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        Changelog
                      </a>
                    </Link>
                  </li>
                  <li>
                    <a href="#" className="text-base text-muted-foreground hover:text-primary">
                      Roadmap
                    </a>
                  </li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <h3 className="text-sm font-semibold text-foreground tracking-wider uppercase">
                  Support
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/support">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        Help Center
                      </a>
                    </Link>
                  </li>
                  <li>
                    <a href="#" className="text-base text-muted-foreground hover:text-primary">
                      Community Forum
                    </a>
                  </li>
                  <li>
                    <Link href="/contact">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        Contact
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/status">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        Status
                      </a>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-foreground tracking-wider uppercase">
                  Company
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/about">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        About
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/careers">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        Careers
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/connect">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        Connect
                      </a>
                    </Link>
                  </li>
                  <li>
                    <a href="#" className="text-base text-muted-foreground hover:text-primary">
                      Partners
                    </a>
                  </li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <h3 className="text-sm font-semibold text-foreground tracking-wider uppercase">
                  Legal
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/privacy">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        Privacy
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/terms">
                      <a className="text-base text-muted-foreground hover:text-primary">
                        Terms
                      </a>
                    </Link>
                  </li>
                  <li>
                    <a href="#" className="text-base text-muted-foreground hover:text-primary">
                      Cookie Policy
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-base text-muted-foreground hover:text-primary">
                      Licenses
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-border pt-8">
          <p className="text-base text-muted-foreground xl:text-center">
            &copy; {new Date().getFullYear()} Flux Communications. All rights reserved.
          </p>
          <p className="text-sm text-muted-foreground mt-2 xl:text-center">
            Created with React, TypeScript, and ShadcnUI. Built with love on Replit.
          </p>
        </div>
      </div>
    </footer>
  );
}