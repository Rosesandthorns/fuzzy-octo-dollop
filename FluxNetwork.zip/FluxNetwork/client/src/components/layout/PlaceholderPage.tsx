import { Link } from "wouter";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

interface PlaceholderPageProps {
  title: string;
  description?: string;
  category?: string;
}

export function PlaceholderPage({ title, description, category }: PlaceholderPageProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-16 px-4">
        <div className="container mx-auto max-w-3xl">
          <div className="flex flex-col items-center text-center mb-12">
            {category && (
              <span className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-2">
                {category}
              </span>
            )}
            <h1 className="text-4xl font-bold tracking-tight mb-4">{title}</h1>
            {description && (
              <p className="text-xl text-muted-foreground max-w-2xl">
                {description}
              </p>
            )}
          </div>
          
          <div className="border border-border rounded-lg p-8 bg-card text-card-foreground mb-10">
            <div className="flex flex-col items-center justify-center py-10 text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
                <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                  <div className="w-4 h-4 bg-primary rounded-full"></div>
                </div>
              </div>
              <h2 className="text-xl font-medium mb-2">Page Under Construction</h2>
              <p className="text-muted-foreground mb-6 max-w-md">
                We're currently working on this page. Check back soon for updates!
              </p>
              <Link href="/">
                <Button className="gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Back to Home
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}