import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { PlusIcon, Upload, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { storage } from "@/lib/firebase";
import { useAuth } from "@/context/AuthContext";
import { v4 as uuidv4 } from "uuid";

interface EmojiUploaderProps {
  onUploadComplete: (emojiUrl: string) => void;
  maxSize?: number; // in MB
  disabled?: boolean;
}

export function EmojiUploader({ 
  onUploadComplete, 
  maxSize = 2, 
  disabled = false 
}: EmojiUploaderProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
      return;
    }

    const file = e.target.files[0];
    
    // Validate file size (MB to bytes)
    if (file.size > maxSize * 1024 * 1024) {
      toast({
        title: "File too large",
        description: `Maximum file size is ${maxSize}MB`,
        variant: "destructive"
      });
      return;
    }
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please upload an image file",
        variant: "destructive"
      });
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUpload = async () => {
    if (!user || !preview || !fileInputRef.current?.files?.length) {
      return;
    }

    const file = fileInputRef.current.files[0];
    setIsUploading(true);

    try {
      // Generate a unique filename with user ID
      const fileExtension = file.name.split('.').pop();
      const fileName = `emojis/${user.uid}/${uuidv4()}.${fileExtension}`;
      const storageRef = ref(storage, fileName);
      
      // Upload the file
      await uploadBytes(storageRef, file);
      
      // Get the download URL
      const downloadUrl = await getDownloadURL(storageRef);
      
      // Call the callback with the URL
      onUploadComplete(downloadUrl);
      
      // Clear the preview
      setPreview(null);
      
      // Reset the file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      
      toast({
        title: "Emoji uploaded",
        description: "Your custom emoji has been uploaded successfully",
      });
    } catch (error) {
      console.error("Error uploading emoji:", error);
      toast({
        title: "Upload failed",
        description: "There was an error uploading your emoji. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const cancelUpload = () => {
    setPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const triggerFileInput = () => {
    if (!disabled) {
      fileInputRef.current?.click();
    }
  };

  return (
    <div className="w-full">
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        accept="image/*"
        onChange={handleFileSelect}
        disabled={disabled || isUploading}
      />
      
      {!preview ? (
        <Button 
          onClick={triggerFileInput} 
          variant="outline" 
          className="w-full h-20 flex flex-col items-center justify-center border-dashed"
          disabled={disabled || isUploading}
        >
          <PlusIcon className="h-5 w-5 mb-1" />
          <span className="text-xs">Upload Custom Emoji</span>
        </Button>
      ) : (
        <div className="relative border rounded-md overflow-hidden">
          <img 
            src={preview} 
            alt="Emoji preview" 
            className="w-full h-24 object-contain bg-muted p-2"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
            <div className="flex space-x-2">
              <Button 
                size="sm" 
                onClick={handleUpload} 
                disabled={isUploading}
                className="bg-green-600 hover:bg-green-700"
              >
                {isUploading ? (
                  <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                ) : (
                  <Upload className="h-4 w-4" />
                )}
              </Button>
              <Button 
                size="sm" 
                variant="destructive" 
                onClick={cancelUpload}
                disabled={isUploading}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
      {preview && (
        <div className="mt-2 flex justify-between text-xs text-muted-foreground">
          <span>Click on the image to upload or cancel</span>
          <span>Max size: {maxSize}MB</span>
        </div>
      )}
    </div>
  );
}