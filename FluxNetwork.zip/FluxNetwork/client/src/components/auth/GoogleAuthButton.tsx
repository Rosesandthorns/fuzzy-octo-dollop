import { Button } from "@/components/ui/button";
import { signInWithGoogleRedirect, signInWithGoogle } from "@/lib/auth";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface GoogleAuthButtonProps {
  onSuccess?: () => void;
}

export default function GoogleAuthButton({ onSuccess }: GoogleAuthButtonProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    try {
      // Use the enhanced redirect method that sets persistence
      await signInWithGoogleRedirect();
      // Note: Due to redirect, we'll need to handle the result in a separate effect
      toast({
        title: "Redirecting to Google",
        description: "Please wait...",
      });
      // We won't reach here due to redirect, but just in case
      setTimeout(() => setIsLoading(false), 5000);
    } catch (error) {
      console.error("Google sign in error:", error);
      toast({
        title: "Authentication failed",
        description: "Could not sign in with Google. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  return (
    <Button
      variant="outline"
      className="w-full bg-white text-black hover:bg-gray-100 dark:bg-white dark:text-black dark:hover:bg-gray-100"
      onClick={handleGoogleSignIn}
      disabled={isLoading}
    >
      {isLoading ? (
        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-b-transparent" />
      ) : (
        <i className="ri-google-fill mr-2 text-lg" />
      )}
      Continue with Google
    </Button>
  );
}
