import { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { userProfileSchema, type UserProfile } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { completeUserProfile, checkUsernameAvailability } from "@/lib/auth";
import { useAuth } from "@/context/AuthContext";
import { useLocation } from "wouter";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useDebounce } from "../../hooks/use-debounce";

const extendedSchema = userProfileSchema.extend({
  confirmPassword: userProfileSchema.shape.password,
  username: z.string()
    .min(3, "Account name must be at least 3 characters")
    .max(20, "Account name must be less than 20 characters")
    .regex(/^[a-zA-Z0-9_]+$/, "Account name can only contain letters, numbers, and underscores")
}).refine(
  (data) => data.password === data.confirmPassword,
  {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  }
);

export default function UsernamePasswordForm() {
  const { toast } = useToast();
  const { refreshUserProfile } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCheckingUsername, setIsCheckingUsername] = useState(false);
  const [isUsernameAvailable, setIsUsernameAvailable] = useState<boolean | null>(null);
  const [, navigate] = useLocation();

  const form = useForm<UserProfile>({
    resolver: zodResolver(extendedSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
    },
  });

  const username = form.watch("username");
  const debouncedUsername = useDebounce(username, 500);

  useEffect(() => {
    const checkUsername = async () => {
      if (!debouncedUsername || debouncedUsername.length < 3) {
        setIsUsernameAvailable(null);
        return;
      }

      setIsCheckingUsername(true);
      try {
        const result = await checkUsernameAvailability(debouncedUsername);
        setIsUsernameAvailable(result.available);
      } catch (error) {
        console.error("Error checking username:", error);
      } finally {
        setIsCheckingUsername(false);
      }
    };

    checkUsername();
  }, [debouncedUsername]);

  const onSubmit = async (data: UserProfile) => {
    if (!isUsernameAvailable) {
      toast({
        title: "Username not available",
        description: "Please choose a different username.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await completeUserProfile(data.username, data.password);
      await refreshUserProfile();
      toast({
        title: "Profile created!",
        description: "Your profile has been successfully created.",
      });
      
      // Redirect to dashboard after successful profile creation
      setTimeout(() => {
        navigate("/dashboard");
      }, 1000);
    } catch (error) {
      console.error("Error completing profile:", error);
      toast({
        title: "Profile creation failed",
        description: "Could not create your profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Account Name</FormLabel>
              <FormControl>
                <div className="relative">
                  <Input
                    placeholder="Choose a permanent account name"
                    {...field}
                    autoComplete="username"
                    className={`${
                      isUsernameAvailable === true ? "border-green-500 focus-visible:ring-green-500" :
                      isUsernameAvailable === false ? "border-red-500 focus-visible:ring-red-500" : ""
                    }`}
                  />
                  {isCheckingUsername && (
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                      <div className="animate-spin h-4 w-4 border-2 border-primary rounded-full border-r-transparent"></div>
                    </div>
                  )}
                </div>
              </FormControl>
              <div className="h-5 text-xs">
                {isUsernameAvailable === true && username.length >= 3 && (
                  <p className="text-green-500">Account name available!</p>
                )}
                {isUsernameAvailable === false && (
                  <p className="text-red-500">Account name already taken</p>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                This will be your permanent ID and cannot be changed later.
              </p>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Password</FormLabel>
              <FormControl>
                <Input
                  type="password"
                  placeholder="Create a secure password"
                  {...field}
                  autoComplete="new-password"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="confirmPassword"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Confirm Password</FormLabel>
              <FormControl>
                <Input
                  type="password"
                  placeholder="Confirm your password"
                  {...field}
                  autoComplete="new-password"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="flex gap-3 pt-2">
          <Button
            type="submit"
            className="flex-1"
            disabled={isSubmitting || isUsernameAvailable === false}
          >
            {isSubmitting && (
              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-b-transparent"></div>
            )}
            Complete Profile
          </Button>
        </div>
      </form>
    </Form>
  );
}
