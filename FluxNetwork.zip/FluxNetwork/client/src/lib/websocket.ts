import { useEffect, useState } from "react";

/**
 * WebSocketManager - Manages WebSocket connection and message handling
 * Handles reconnection logic, message sending, and event listeners
 */
class WebSocketManager {
  private socket: WebSocket | null = null;
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 2000; // Start with 2 seconds
  private listeners: Map<string, Array<(data: any) => void>> = new Map();
  private isConnected = false;

  /**
   * Connect to the WebSocket server
   */
  connect() {
    if (this.socket?.readyState === WebSocket.OPEN) return;

    // Clear any existing reconnect timeouts
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }

    // Create WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    this.socket = new WebSocket(wsUrl);
    
    // Setup event handlers
    this.socket.onopen = this.handleOpen.bind(this);
    this.socket.onmessage = this.handleMessage.bind(this);
    this.socket.onclose = this.handleClose.bind(this);
    this.socket.onerror = this.handleError.bind(this);
  }

  /**
   * Disconnect from the WebSocket server
   */
  disconnect() {
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
    
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }
    
    this.isConnected = false;
  }

  /**
   * Send a message to the WebSocket server
   * @param type - Message type
   * @param payload - Message payload
   * @returns Boolean indicating if message was sent
   */
  send(type: string, payload: any) {
    if (!this.socket || this.socket.readyState !== WebSocket.OPEN) {
      console.warn('WebSocket not connected, cannot send message');
      return false;
    }

    try {
      this.socket.send(JSON.stringify({ type, payload }));
      return true;
    } catch (error) {
      console.error('Error sending WebSocket message:', error);
      return false;
    }
  }

  /**
   * Register a listener for a specific message type
   * @param type - Message type to listen for
   * @param callback - Function to call when message is received
   */
  on(type: string, callback: (data: any) => void) {
    if (!this.listeners.has(type)) {
      this.listeners.set(type, []);
    }
    
    this.listeners.get(type)!.push(callback);
  }

  /**
   * Remove a listener for a specific message type
   * @param type - Message type
   * @param callback - Function to remove
   */
  off(type: string, callback: (data: any) => void) {
    if (!this.listeners.has(type)) return;
    
    const typeListeners = this.listeners.get(type)!;
    const index = typeListeners.indexOf(callback);
    
    if (index !== -1) {
      typeListeners.splice(index, 1);
    }
  }

  /**
   * Check if the WebSocket is connected
   * @returns Boolean indicating connection status
   */
  isSocketConnected() {
    return this.isConnected;
  }

  /**
   * Handle WebSocket open event
   */
  private handleOpen(event: Event) {
    console.log('WebSocket connected');
    this.isConnected = true;
    this.reconnectAttempts = 0;
    
    // Notify connection listeners
    this.notifyListeners('connection', { 
      status: 'connected',
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Handle WebSocket message event
   */
  private handleMessage(event: MessageEvent) {
    try {
      const data = JSON.parse(event.data);
      
      // Notify type-specific listeners
      if (data.type) {
        this.notifyListeners(data.type, data.payload);
      }
      
      // Also notify generic message listeners
      this.notifyListeners('message', data);
    } catch (error) {
      console.error('Error parsing WebSocket message:', error);
    }
  }

  /**
   * Handle WebSocket close event
   */
  private handleClose(event: CloseEvent) {
    console.log('WebSocket disconnected:', event.code, event.reason);
    this.isConnected = false;
    this.socket = null;
    
    // Notify connection listeners
    this.notifyListeners('connection', { 
      status: 'disconnected',
      code: event.code,
      reason: event.reason,
      timestamp: new Date().toISOString()
    });
    
    // Attempt to reconnect
    this.attemptReconnect();
  }

  /**
   * Handle WebSocket error event
   */
  private handleError(event: Event) {
    console.error('WebSocket error:', event);
    
    // Notify error listeners
    this.notifyListeners('error', { 
      event,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Attempt to reconnect to the WebSocket server
   */
  private attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.log('Maximum reconnect attempts reached');
      return;
    }
    
    this.reconnectAttempts++;
    const delay = this.reconnectDelay * Math.pow(1.5, this.reconnectAttempts - 1);
    
    console.log(`Attempting to reconnect in ${delay}ms (attempt ${this.reconnectAttempts})`);
    
    this.reconnectTimeout = setTimeout(() => {
      this.connect();
    }, delay);
  }

  /**
   * Notify all listeners for a specific message type
   * @param type - Message type
   * @param data - Message data
   */
  private notifyListeners(type: string, data: any) {
    const listeners = this.listeners.get(type);
    
    if (listeners) {
      listeners.forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error(`Error in WebSocket listener for ${type}:`, error);
        }
      });
    }
  }
}

// Singleton instance
export const webSocketManager = new WebSocketManager();

/**
 * React hook for WebSocket functionality
 * @returns WebSocket connection status
 */
export function useWebSocket() {
  const [isConnected, setIsConnected] = useState(false);
  
  useEffect(() => {
    const handleConnection = (data: any) => {
      setIsConnected(data.status === 'connected');
    };
    
    webSocketManager.on('connection', handleConnection);
    
    // Initialize connection status
    setIsConnected(webSocketManager.isSocketConnected());
    
    return () => {
      webSocketManager.off('connection', handleConnection);
    };
  }, []);
  
  return { isConnected };
}