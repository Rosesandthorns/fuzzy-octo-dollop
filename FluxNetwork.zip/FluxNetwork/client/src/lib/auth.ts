import { auth, googleProvider, db } from "./firebase";
import { 
  signInWithPopup, 
  signInWithRedirect, 
  getRedirectResult,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  User as FirebaseUser,
  browserLocalPersistence,
  setPersistence
} from "firebase/auth";
import { 
  doc, 
  getDoc, 
  setDoc, 
  collection,
  query,
  where,
  getDocs,
  updateDoc,
  arrayUnion,
  arrayRemove,
  serverTimestamp
} from "firebase/firestore";
import { apiRequest } from "./queryClient";

// Sign in with Google using popup (better for desktop)
export const signInWithGoogle = async () => {
  try {
    return await signInWithPopup(auth, googleProvider);
  } catch (error) {
    console.error("Error signing in with Google", error);
    throw error;
  }
};

// Sign in with Google using redirect (better for mobile)
export const signInWithGoogleRedirect = async () => {
  try {
    // Set persistence to LOCAL to remember user between sessions
    await setPersistence(auth, browserLocalPersistence);
    // Then redirect to Google sign-in
    return signInWithRedirect(auth, googleProvider);
  } catch (error) {
    console.error("Error setting persistence before redirect:", error);
    throw error;
  }
};

// Handle redirect result
export const handleRedirectResult = async () => {
  try {
    // Check if we already have an authenticated user
    const currentUser = auth.currentUser;
    if (currentUser) {
      console.log("User already authenticated, no need to process redirect");
      return { user: currentUser };
    }
    
    const result = await getRedirectResult(auth);
    if (result && result.user) {
      console.log("Successfully signed in after redirect");
      // Persist the user data to firestore if needed
      await saveUserToFirestore(result.user);
    }
    return result;
  } catch (error) {
    console.error("Error handling redirect result", error);
    // Instead of throwing, we'll return null to avoid cascading errors
    // This handles the common "auth/argument-error" that occurs when there's no redirect in progress
    return null;
  }
};

// Complete profile after Google auth
export const completeUserProfile = async (username: string, password: string) => {
  const user = auth.currentUser;
  if (!user) throw new Error("No authenticated user");

  try {
    const { email, uid, displayName, photoURL } = user;
    
    await apiRequest("POST", "/api/users", {
      username,
      password,
      email: email || "",
      firebaseUid: uid,
      displayName: displayName || "",
      avatarUrl: photoURL || ""
    });
    
    return true;
  } catch (error) {
    console.error("Error completing profile", error);
    throw error;
  }
};

// Sign out
export const signOut = async () => {
  try {
    await firebaseSignOut(auth);
    // Optional: Clear any local storage or context
    return true;
  } catch (error) {
    console.error("Error signing out", error);
    throw error;
  }
};

// Get current user
export const getCurrentUser = (): FirebaseUser | null => {
  return auth.currentUser;
};

// Listen for auth state changes
export const onAuthChange = (callback: (user: FirebaseUser | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

// Check if user has completed profile
export const checkUserProfile = async (uid: string) => {
  try {
    // First try the API
    const response = await fetch(`/api/users/firebase/${uid}`);
    if (response.ok) {
      return await response.json();
    }
    
    // If API fails, check Firestore
    const userDocRef = doc(db, "users", uid);
    const userDocSnap = await getDoc(userDocRef);
    
    if (userDocSnap.exists()) {
      return userDocSnap.data();
    }
    
    return null;
  } catch (error) {
    console.error("Error checking user profile", error);
    return null;
  }
};

// Get user from Firestore
export const getUserFromFirestore = async (uid: string) => {
  try {
    const userDocRef = doc(db, "users", uid);
    const userDocSnap = await getDoc(userDocRef);
    
    if (userDocSnap.exists()) {
      return userDocSnap.data();
    }
    return null;
  } catch (error) {
    console.error("Error getting user from Firestore", error);
    return null;
  }
};

// Save user to Firestore
export const saveUserToFirestore = async (user: FirebaseUser, additionalData?: any) => {
  if (!user) return null;
  
  const { uid, displayName, email, photoURL } = user;
  const userRef = doc(db, "users", uid);
  
  try {
    const userSnap = await getDoc(userRef);
    
    if (!userSnap.exists()) {
      // Create new user document
      const userData = {
        uid,
        displayName: displayName || "",
        email: email || "",
        avatarUrl: photoURL || "",
        username: additionalData?.username || email?.split('@')[0] || "",
        friends: [],
        rooms: [],
        createdAt: serverTimestamp(),
        lastLogin: serverTimestamp(),
        tier: "basic", // Default tier for new users
        // Set default theme settings
        themeSettings: {
          mode: "system",
          color: "#7C3AED", // Default purple color
          customEmojis: [],
          tier: "basic"
        },
        ...additionalData
      };
      
      // Save the user data to main document
      await setDoc(userRef, userData);
      
      // Also initialize the theme settings document
      const userThemeRef = doc(db, "users", uid, "settings", "theme");
      await setDoc(userThemeRef, {
        mode: "system",
        color: "#7C3AED",
        customEmojis: [],
        tier: "basic"
      });
      
      // Initialize empty blocked users collection
      const blockedUsersRef = doc(db, "users", uid, "settings", "blockedUsers");
      await setDoc(blockedUsersRef, { users: [] });
      
      return userData;
    } else {
      // Update last login
      await updateDoc(userRef, {
        lastLogin: serverTimestamp(),
      });
      
      // Check if theme settings exist, if not create them
      const userThemeRef = doc(db, "users", uid, "settings", "theme");
      const themeSnap = await getDoc(userThemeRef);
      
      if (!themeSnap.exists()) {
        await setDoc(userThemeRef, {
          mode: "system",
          color: "#7C3AED",
          customEmojis: [],
          tier: userSnap.data().tier || "basic"
        });
      }
      
      // Check if blocked users document exists, if not create it
      const blockedUsersRef = doc(db, "users", uid, "settings", "blockedUsers");
      const blockedUsersSnap = await getDoc(blockedUsersRef);
      
      if (!blockedUsersSnap.exists()) {
        await setDoc(blockedUsersRef, { users: [] });
      }
      
      return userSnap.data();
    }
  } catch (error) {
    console.error("Error saving user to Firestore", error);
    return null;
  }
};

// Verify if username is available
export const checkUsernameAvailability = async (username: string) => {
  try {
    const response = await fetch(`/api/users/check-username/${username}`);
    if (response.ok) {
      return await response.json();
    }
    return { available: false };
  } catch (error) {
    console.error("Error checking username availability", error);
    return { available: false };
  }
};

// Sign up with email and password
export const signUpWithEmail = async (email: string, password: string) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error("Error signing up with email", error);
    throw error;
  }
};

// Sign in with email and password
export const signInWithEmail = async (email: string, password: string) => {
  try {
    // Set persistence first to remember the user
    await setPersistence(auth, browserLocalPersistence);
    
    // Then sign in
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    
    // Save to Firestore
    await saveUserToFirestore(userCredential.user);
    
    return userCredential.user;
  } catch (error) {
    console.error("Error signing in with email", error);
    throw error;
  }
};

// Friend functions
export interface Friend {
  id: string;
  username: string;
  displayName: string;
  avatar?: string;
  status: "online" | "idle" | "offline" | "dnd";
  statusText?: string;
}

export interface FriendRequest {
  id: string;
  username: string;
  displayName: string;
  avatar?: string;
  incoming: boolean;
  sentAt: string;
}

export const getFriends = async (uid: string): Promise<Friend[]> => {
  try {
    const userRef = doc(db, "users", uid);
    const userSnap = await getDoc(userRef);
    
    if (!userSnap.exists()) {
      return [];
    }
    
    const userData = userSnap.data();
    if (!userData.friends || !Array.isArray(userData.friends)) {
      return [];
    }
    
    // Get friend data
    const friendPromises = userData.friends.map(async (friendId: string) => {
      const friendRef = doc(db, "users", friendId);
      const friendSnap = await getDoc(friendRef);
      
      if (friendSnap.exists()) {
        const friendData = friendSnap.data();
        return {
          id: friendId,
          username: friendData.username || "",
          displayName: friendData.displayName || "",
          avatar: friendData.avatarUrl,
          status: (friendData.status as "online" | "idle" | "offline" | "dnd") || "offline",
          statusText: friendData.statusText
        };
      }
      return null;
    });
    
    const friends = await Promise.all(friendPromises);
    return friends.filter(Boolean) as Friend[];
  } catch (error) {
    console.error("Error getting friends", error);
    return [];
  }
};

export const sendFriendRequest = async (fromUserId: string, toUsername: string) => {
  try {
    // Find user by username
    const usersRef = collection(db, "users");
    const q = query(usersRef, where("username", "==", toUsername));
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) {
      throw new Error("User not found");
    }
    
    const toUser = querySnapshot.docs[0];
    const toUserId = toUser.id;
    
    // Prevent sending request to self
    if (fromUserId === toUserId) {
      throw new Error("You cannot send a friend request to yourself");
    }
    
    // Check if already friends
    const fromUserRef = doc(db, "users", fromUserId);
    const fromUserSnap = await getDoc(fromUserRef);
    
    if (fromUserSnap.exists() && fromUserSnap.data().friends && fromUserSnap.data().friends.includes(toUserId)) {
      throw new Error("You are already friends with this user");
    }
    
    // Add friend request
    const requestRef = doc(db, "friendRequests", `${fromUserId}_${toUserId}`);
    await setDoc(requestRef, {
      from: fromUserId,
      to: toUserId,
      status: "pending",
      createdAt: serverTimestamp()
    });
    
    return true;
  } catch (error) {
    console.error("Error sending friend request", error);
    throw error;
  }
};

export const getFriendRequests = async (userId: string): Promise<FriendRequest[]> => {
  try {
    // Get incoming requests
    const requestsRef = collection(db, "friendRequests");
    const q = query(requestsRef, where("to", "==", userId), where("status", "==", "pending"));
    const querySnapshot = await getDocs(q);
    
    // Get request data with sender info
    const requestPromises = querySnapshot.docs.map(async (requestDoc) => {
      const requestData = requestDoc.data();
      const fromUserRef = doc(db, "users", requestData.from);
      const fromUserSnap = await getDoc(fromUserRef);
      
      if (fromUserSnap.exists()) {
        const fromUserData = fromUserSnap.data();
        return {
          id: requestDoc.id,
          username: fromUserData.username || "",
          displayName: fromUserData.displayName || "",
          avatar: fromUserData.avatarUrl,
          incoming: true,
          sentAt: requestData.createdAt ? new Date(requestData.createdAt.toDate()).toLocaleString() : 'Just now'
        };
      }
      return null;
    });
    
    // Get outgoing requests
    const outgoingQ = query(requestsRef, where("from", "==", userId), where("status", "==", "pending"));
    const outgoingSnapshot = await getDocs(outgoingQ);
    
    const outgoingPromises = outgoingSnapshot.docs.map(async (requestDoc) => {
      const requestData = requestDoc.data();
      const toUserRef = doc(db, "users", requestData.to);
      const toUserSnap = await getDoc(toUserRef);
      
      if (toUserSnap.exists()) {
        const toUserData = toUserSnap.data();
        return {
          id: requestDoc.id,
          username: toUserData.username || "",
          displayName: toUserData.displayName || "",
          avatar: toUserData.avatarUrl,
          incoming: false,
          sentAt: requestData.createdAt ? new Date(requestData.createdAt.toDate()).toLocaleString() : 'Just now'
        };
      }
      return null;
    });
    
    const allPromises = [...requestPromises, ...outgoingPromises];
    const requests = await Promise.all(allPromises);
    
    return requests.filter(Boolean) as FriendRequest[];
  } catch (error) {
    console.error("Error getting friend requests", error);
    return [];
  }
};

export const acceptFriendRequest = async (requestId: string) => {
  try {
    const requestRef = doc(db, "friendRequests", requestId);
    const requestSnap = await getDoc(requestRef);
    
    if (!requestSnap.exists()) {
      throw new Error("Friend request not found");
    }
    
    const requestData = requestSnap.data();
    
    // Add each user to the other's friends list
    const fromUserRef = doc(db, "users", requestData.from);
    const toUserRef = doc(db, "users", requestData.to);
    
    await updateDoc(fromUserRef, {
      friends: arrayUnion(requestData.to)
    });
    
    await updateDoc(toUserRef, {
      friends: arrayUnion(requestData.from)
    });
    
    // Update request status
    await updateDoc(requestRef, {
      status: "accepted",
      updatedAt: serverTimestamp()
    });
    
    return true;
  } catch (error) {
    console.error("Error accepting friend request", error);
    throw error;
  }
};

export const rejectFriendRequest = async (requestId: string) => {
  try {
    const requestRef = doc(db, "friendRequests", requestId);
    const requestSnap = await getDoc(requestRef);
    
    if (!requestSnap.exists()) {
      throw new Error("Friend request not found");
    }
    
    // Update request status
    await updateDoc(requestRef, {
      status: "rejected",
      updatedAt: serverTimestamp()
    });
    
    return true;
  } catch (error) {
    console.error("Error rejecting friend request", error);
    throw error;
  }
};

export const removeFriend = async (userId: string, friendId: string) => {
  try {
    const userRef = doc(db, "users", userId);
    const friendRef = doc(db, "users", friendId);
    
    // Remove from each other's friends lists
    await updateDoc(userRef, {
      friends: arrayRemove(friendId)
    });
    
    await updateDoc(friendRef, {
      friends: arrayRemove(userId)
    });
    
    return true;
  } catch (error) {
    console.error("Error removing friend", error);
    throw error;
  }
};
