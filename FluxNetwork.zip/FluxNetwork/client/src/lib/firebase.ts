import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider, 
  setPersistence, 
  browserLocalPersistence, 
  initializeAuth,
  indexedDBLocalPersistence
} from "firebase/auth";
import { initializeFirestore, getFirestore, connectFirestoreEmulator } from "firebase/firestore";
import { enableIndexedDbPersistence } from "firebase/firestore"; 

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
  messagingSenderId: "587303039653",
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  measurementId: "G-DZJ0Z9YT18"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Auth with persistence
// Make auth variable globally available for export
let auth: ReturnType<typeof getAuth>;

// Use initializeAuth with indexedDBLocalPersistence for better persistence across sessions
try {
  auth = initializeAuth(app, {
    persistence: [indexedDBLocalPersistence, browserLocalPersistence]
  });
  console.log("Firebase auth initialized with persistent storage");
} catch (error) {
  console.error("Error initializing auth with persistence:", error);
  // Fallback to standard auth if initialization fails
  auth = getAuth(app);
  // Still try to set persistence
  setPersistence(auth, browserLocalPersistence)
    .then(() => console.log("Persistence set successfully"))
    .catch((error) => {
      console.error("Error setting persistence:", error);
    });
}

// Initialize Firestore with persistence
const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});

// Enable offline persistence
enableIndexedDbPersistence(db)
  .catch((err) => {
    if (err.code === 'failed-precondition') {
      // Multiple tabs open, persistence can only be enabled in one tab at a time
      console.error('Persistence failed: Multiple tabs open');
    } else if (err.code === 'unimplemented') {
      // The current browser does not support persistence
      console.error('Persistence not supported by browser');
    } else {
      console.error('Persistence error:', err);
    }
  });

// Configure Google provider
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

// Export firestore alias for db for clarity when importing
const firestore = db;

export { app, auth, googleProvider, db, firestore };
