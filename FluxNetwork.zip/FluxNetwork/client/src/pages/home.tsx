import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-12 md:py-24 bg-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                  Welcome to Flux
                </h1>
                <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                  The modern platform for seamless communication
                </p>
              </div>
              <div className="space-x-4">
                <Link href="/login">
                  <Button size="lg" className="px-8">Get Started</Button>
                </Link>
                <Link href="/features">
                  <Button variant="outline" size="lg">Learn More</Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-12 md:py-24 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                  Powerful Features
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Everything you need for effective communication and collaboration
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 lg:gap-12 mt-8">
              {/* Feature 1 */}
              <div className="flex flex-col items-center space-y-2 border border-border p-6 rounded-lg">
                <i className="ri-message-3-line text-4xl text-primary"></i>
                <h3 className="text-xl font-bold">Real-time Messaging</h3>
                <p className="text-muted-foreground text-center">
                  Communicate with your team in real-time with instant messaging.
                </p>
              </div>
              
              {/* Feature 2 */}
              <div className="flex flex-col items-center space-y-2 border border-border p-6 rounded-lg">
                <i className="ri-team-line text-4xl text-primary"></i>
                <h3 className="text-xl font-bold">Team Collaboration</h3>
                <p className="text-muted-foreground text-center">
                  Create teams, channels, and workspaces for organized collaboration.
                </p>
              </div>
              
              {/* Feature 3 */}
              <div className="flex flex-col items-center space-y-2 border border-border p-6 rounded-lg">
                <i className="ri-shield-check-line text-4xl text-primary"></i>
                <h3 className="text-xl font-bold">Secure & Private</h3>
                <p className="text-muted-foreground text-center">
                  Enterprise-grade security with end-to-end encryption.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-24 bg-primary text-primary-foreground">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                  Ready to Get Started?
                </h2>
                <p className="mx-auto max-w-[600px] text-primary-foreground/80 md:text-xl">
                  Join thousands of teams already using Flux to improve their communication.
                </p>
              </div>
              <div className="mx-auto w-full max-w-sm space-y-2">
                <Link href="/login">
                  <Button 
                    className="w-full bg-white text-primary hover:bg-primary-foreground"
                    size="lg"
                  >
                    Sign Up Now
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
