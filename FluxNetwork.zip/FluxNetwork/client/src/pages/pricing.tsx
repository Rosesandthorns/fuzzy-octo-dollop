import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, HelpCircle, Sparkles, Zap } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface PlanFeature {
  text: string;
  available: boolean;
  tooltip?: string;
}

interface PricingPlan {
  name: string;
  description: string;
  price: string;
  priceDetail: string;
  icon: React.ReactNode;
  features: PlanFeature[];
  popularPlan?: boolean;
  buttonText: string;
  buttonVariant?: "default" | "outline" | "secondary";
}

export default function PricingPage() {
  const pricingPlans: PricingPlan[] = [
    {
      name: "Free",
      description: "Everything you need to get started with Flux",
      price: "$0",
      priceDetail: "Free forever",
      icon: <Check className="h-5 w-5 text-primary" />,
      buttonText: "Get Started",
      buttonVariant: "outline",
      features: [
        { text: "1 of 3 preset room colors", available: true },
        { text: "Limited custom profile emojis (up to 15)", available: true },
        { text: "Access to 100 rooms", available: true },
        { text: "Minimal, but present backgrounds / theme control", available: true },
        { text: "Make up to 15 rooms at a time", available: true },
        { text: "Basic support", available: true },
      ],
    },
    {
      name: "Glow",
      description: "Enhanced features with a one-time payment",
      price: "$5",
      priceDetail: "One-time payment",
      icon: <Sparkles className="h-5 w-5 text-amber-500" />,
      buttonText: "Upgrade to Glow",
      popularPlan: true,
      features: [
        { text: "Custom room colors (up to 25)", available: true },
        { text: "50 profile emojis", available: true },
        { text: "Access to Glow rooms (premium chat)", available: true },
        { text: "Basic background customization (25 preset options only)", available: true },
        { text: "Make up to 30 rooms", available: true },
        { text: "Everything in Free tier", available: true },
      ],
    },
    {
      name: "Echo",
      description: "Premium features for power users",
      price: "$5+",
      priceDetail: "per month",
      icon: <Zap className="h-5 w-5 text-purple-500" />,
      buttonText: "Subscribe to Echo",
      buttonVariant: "secondary",
      features: [
        { text: "Full background control (custom gradients, hex codes, animated options)", available: true, tooltip: "Complete customization of your Flux experience" },
        { text: "150 custom profile emojis", available: true },
        { text: "Up to 50 room prefixes (custom tags)", available: true },
        { text: "Priority support", available: true },
        { text: "Make up to 55 rooms", available: true },
        { text: "Dev logs and Q&A access", available: true },
        { text: "Everything from Free + Glow tiers", available: true },
      ],
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow">
        {/* Hero section */}
        <section className="bg-gradient-to-r from-primary/10 via-primary/5 to-background pt-20 pb-16">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center text-center space-y-4">
              <h1 className="text-3xl md:text-5xl font-bold tracking-tighter">
                Simple, Transparent Pricing
              </h1>
              <p className="text-muted-foreground md:text-xl max-w-[800px]">
                Choose the plan that works best for you, with no hidden fees or surprise charges.
              </p>
            </div>
          </div>
        </section>

        {/* Pricing plans */}
        <section className="py-16 px-4 md:px-6">
          <div className="container">
            <Tabs defaultValue="plans" className="w-full">
              <TabsList className="grid w-full max-w-md grid-cols-2 mx-auto mb-8">
                <TabsTrigger value="plans">Plans</TabsTrigger>
                <TabsTrigger value="compare">Compare Features</TabsTrigger>
              </TabsList>
              
              <TabsContent value="plans" className="w-full">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {pricingPlans.map((plan) => (
                    <Card 
                      key={plan.name} 
                      className={`flex flex-col ${plan.popularPlan ? 'border-primary shadow-lg relative' : ''}`}
                    >
                      {plan.popularPlan && (
                        <div className="absolute top-0 right-0 transform translate-x-2 -translate-y-2">
                          <span className="bg-primary text-primary-foreground text-xs px-3 py-1 rounded-full font-medium">
                            Most Popular
                          </span>
                        </div>
                      )}
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-xl flex items-center gap-2">
                            {plan.icon}
                            {plan.name}
                          </CardTitle>
                        </div>
                        <CardDescription>{plan.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-grow">
                        <div className="flex items-baseline mb-6">
                          <span className="text-3xl font-bold">{plan.price}</span>
                          <span className="ml-1 text-muted-foreground">{plan.priceDetail}</span>
                        </div>
                        <ul className="space-y-3">
                          {plan.features.map((feature, i) => (
                            <li key={i} className="flex items-start gap-2">
                              <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                              <span className="text-sm">{feature.text}</span>
                              {feature.tooltip && (
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger>
                                      <HelpCircle className="h-4 w-4 text-muted-foreground" />
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>{feature.tooltip}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              )}
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                      <CardFooter>
                        <Button 
                          className="w-full"
                          variant={plan.buttonVariant || "default"}
                        >
                          {plan.buttonText}
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="compare" className="w-full">
                <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
                  <div className="p-6">
                    <h3 className="text-lg font-medium">Plan Comparison</h3>
                    <p className="text-sm text-muted-foreground">Detailed feature comparison across all plans</p>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-4">Feature</th>
                          <th className="p-4 text-center">Free</th>
                          <th className="p-4 text-center">Glow</th>
                          <th className="p-4 text-center">Echo</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b">
                          <td className="p-4 font-medium">Room Colors</td>
                          <td className="p-4 text-center">1 of 3 preset colors</td>
                          <td className="p-4 text-center">Up to 25 custom colors</td>
                          <td className="p-4 text-center">Unlimited custom colors</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-4 font-medium">Profile Emojis</td>
                          <td className="p-4 text-center">Up to 15</td>
                          <td className="p-4 text-center">Up to 50</td>
                          <td className="p-4 text-center">Up to 150</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-4 font-medium">Room Access</td>
                          <td className="p-4 text-center">100 rooms</td>
                          <td className="p-4 text-center">Unlimited + Glow rooms</td>
                          <td className="p-4 text-center">Unlimited + Premium rooms</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-4 font-medium">Background Customization</td>
                          <td className="p-4 text-center">Minimal</td>
                          <td className="p-4 text-center">25 preset options</td>
                          <td className="p-4 text-center">Full control with animations</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-4 font-medium">Room Creation</td>
                          <td className="p-4 text-center">Up to 15 rooms</td>
                          <td className="p-4 text-center">Up to 30 rooms</td>
                          <td className="p-4 text-center">Up to 55 rooms</td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-4 font-medium">Room Prefixes</td>
                          <td className="p-4 text-center">None</td>
                          <td className="p-4 text-center">Basic (5)</td>
                          <td className="p-4 text-center">Up to 50 custom</td>
                        </tr>
                        <tr>
                          <td className="p-4 font-medium">Support Level</td>
                          <td className="p-4 text-center">Standard</td>
                          <td className="p-4 text-center">Standard</td>
                          <td className="p-4 text-center">Priority</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-16 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Frequently Asked Questions</h2>
              <p className="text-muted-foreground max-w-[700px] mx-auto">
                Got questions about our pricing? Find answers to the most common questions below.
              </p>
            </div>
            <div className="grid gap-6 md:grid-cols-2 max-w-4xl mx-auto">
              {[
                {
                  question: "Do I need to provide payment information for the free plan?",
                  answer: "No, you can use the Free plan without providing any payment information. Sign up and start using Flux immediately with no credit card required."
                },
                {
                  question: "Can I upgrade or downgrade my plan at any time?",
                  answer: "Yes! You can upgrade from Free to Glow or Echo at any time. Since Glow is a one-time payment, you'll keep those benefits even if you cancel your Echo subscription."
                },
                {
                  question: "What happens to my custom settings if I downgrade?",
                  answer: "If you downgrade from Echo to Glow or Free, your custom settings will be saved but inactive until you upgrade again. You won't lose your configurations."
                },
                {
                  question: "Are there any discounts for annual payments?",
                  answer: "Yes, we offer a 15% discount when you subscribe to Echo annually instead of monthly. This option is available at checkout."
                },
              ].map((item, i) => (
                <Card key={i} className="h-full">
                  <CardHeader>
                    <CardTitle className="text-lg">{item.question}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{item.answer}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}