import { useState, useEffect } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Search, UserPlus, UserCheck, UserX, MessageSquare, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { 
  getFriends, 
  sendFriendRequest, 
  getFriendRequests, 
  acceptFriendRequest, 
  rejectFriendRequest, 
  removeFriend 
} from "@/lib/auth";
import { useAuth } from "@/context/AuthContext";

interface Friend {
  id: string;
  username: string;
  displayName: string;
  avatar?: string;
  status: "online" | "idle" | "offline" | "dnd";
  statusText?: string;
}

interface FriendRequest {
  id: string;
  username: string;
  displayName: string;
  avatar?: string;
  incoming: boolean;
  sentAt: string;
}

export default function FriendsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [addFriendInput, setAddFriendInput] = useState("");
  const [friends, setFriends] = useState<Friend[]>([]);
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Load friends from Firestore
  useEffect(() => {
    const loadFriends = async () => {
      if (!user) return;
      
      try {
        setIsLoading(true);
        const friendsData = await getFriends(user.uid);
        setFriends(friendsData as Friend[]);
        
        const requestsData = await getFriendRequests(user.uid);
        setFriendRequests(requestsData as FriendRequest[]);
      } catch (error) {
        console.error("Error loading friends:", error);
        toast({
          title: "Error",
          description: "Failed to load friends data.",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    loadFriends();
  }, [user, toast]);

  const filteredFriends = friends.filter(friend => 
    friend.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    friend.displayName.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const incomingRequests = friendRequests.filter(req => req.incoming);
  const outgoingRequests = friendRequests.filter(req => !req.incoming);

  const handleAddFriend = async () => {
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to add friends",
        variant: "destructive"
      });
      return;
    }
    
    if (!addFriendInput.trim()) {
      toast({
        title: "Error",
        description: "Please enter a username",
        variant: "destructive"
      });
      return;
    }
    
    try {
      await sendFriendRequest(user.uid, addFriendInput.trim());
      
      toast({
        title: "Friend Request Sent",
        description: `Your friend request to ${addFriendInput} has been sent!`,
      });
      
      // Refresh friend requests
      const requestsData = await getFriendRequests(user.uid);
      setFriendRequests(requestsData as FriendRequest[]);
      
      setAddFriendInput("");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to send friend request",
        variant: "destructive"
      });
    }
  };
  
  const handleAcceptRequest = async (request: FriendRequest) => {
    if (!user) return;
    
    try {
      await acceptFriendRequest(request.id);
      
      toast({
        title: "Friend Request Accepted",
        description: `You are now friends with ${request.displayName}`,
      });
      
      // Refresh friends and requests
      const friendsData = await getFriends(user.uid);
      setFriends(friendsData as Friend[]);
      
      const requestsData = await getFriendRequests(user.uid);
      setFriendRequests(requestsData as FriendRequest[]);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to accept friend request",
        variant: "destructive"
      });
    }
  };
  
  const handleRejectRequest = async (request: FriendRequest) => {
    if (!user) return;
    
    try {
      await rejectFriendRequest(request.id);
      
      toast({
        title: "Friend Request Rejected",
        description: `You rejected ${request.displayName}'s friend request`,
      });
      
      // Refresh requests
      const requestsData = await getFriendRequests(user.uid);
      setFriendRequests(requestsData as FriendRequest[]);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to reject friend request",
        variant: "destructive"
      });
    }
  };
  
  const handleCancelRequest = async (request: FriendRequest) => {
    if (!user) return;
    
    try {
      // For canceling outgoing requests, we use reject
      await rejectFriendRequest(request.id);
      
      toast({
        title: "Friend Request Cancelled",
        description: `Your friend request to ${request.displayName} has been cancelled`,
      });
      
      // Refresh requests
      const requestsData = await getFriendRequests(user.uid);
      setFriendRequests(requestsData as FriendRequest[]);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to cancel friend request",
        variant: "destructive"
      });
    }
  };
  
  const handleRemoveFriend = async (friend: Friend) => {
    if (!user) return;
    
    try {
      await removeFriend(user.uid, friend.id);
      
      toast({
        title: "Friend Removed",
        description: `${friend.displayName} has been removed from your friends`,
        variant: "destructive"
      });
      
      // Refresh friends
      const friendsData = await getFriends(user.uid);
      setFriends(friendsData as Friend[]);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to remove friend",
        variant: "destructive"
      });
    }
  };

  return (
    <AppLayout>
      <div className="h-full flex flex-col">
        <div className="flex-shrink-0 border-b border-border p-4">
          <h1 className="text-2xl font-bold mb-4">Friends</h1>
          
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search friends..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="flex-1">
                  <Input
                    placeholder="Enter a username..."
                    value={addFriendInput}
                    onChange={(e) => setAddFriendInput(e.target.value)}
                  />
                </div>
                <Button className="ml-2" onClick={handleAddFriend}>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Add Friend
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="all" className="flex-1 flex flex-col">
          <TabsList className="w-full px-4 py-2">
            <TabsTrigger value="all" className="flex items-center">
              All Friends {filteredFriends.length > 0 && `(${filteredFriends.length})`}
            </TabsTrigger>
            <TabsTrigger value="online" className="flex items-center">
              Online {filteredFriends.filter(f => f.status === "online").length > 0 && 
                `(${filteredFriends.filter(f => f.status === "online").length})`}
            </TabsTrigger>
            <TabsTrigger value="pending" className="flex items-center">
              Pending {friendRequests.length > 0 && `(${friendRequests.length})`}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="flex-1 p-0 m-0">
            <ScrollArea className="h-full">
              <div className="p-4">
                {filteredFriends.length === 0 ? (
                  <div className="flex flex-col items-center justify-center p-8 text-center">
                    <UserCheck className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No friends found</h3>
                    <p className="text-sm text-muted-foreground max-w-md mb-4">
                      {searchQuery ? 
                        "Try a different search term or clear your search" : 
                        "Add some friends to get started with your conversations"
                      }
                    </p>
                    <Button variant="outline" onClick={() => setSearchQuery("")}>
                      {searchQuery ? "Clear Search" : "Add a Friend"}
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredFriends.map((friend) => (
                      <div key={friend.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                        <div className="flex items-center">
                          <div className="relative">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={friend.avatar} />
                              <AvatarFallback className="bg-primary text-primary-foreground">
                                {friend.displayName.substring(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <span className={cn(
                              "absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background",
                              friend.status === "online" ? "bg-green-500" :
                              friend.status === "idle" ? "bg-yellow-500" :
                              friend.status === "dnd" ? "bg-red-500" : "bg-gray-400"
                            )} />
                          </div>
                          <div className="ml-3">
                            <div className="flex items-center">
                              <p className="font-medium">{friend.displayName}</p>
                              <span className="text-xs text-muted-foreground ml-2">@{friend.username}</span>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {friend.status === "online" ? (friend.statusText || "Online") :
                              friend.status === "idle" ? (friend.statusText || "Idle") :
                              friend.status === "dnd" ? (friend.statusText || "Do Not Disturb") : "Offline"}
                            </p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Link href={`/dashboard/chat/${friend.id}`}>
                            <Button variant="ghost" size="icon">
                              <MessageSquare className="h-4 w-4" />
                            </Button>
                          </Link>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleRemoveFriend(friend)}
                          >
                            <UserX className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="online" className="flex-1 p-0 m-0">
            <ScrollArea className="h-full">
              <div className="p-4">
                {filteredFriends.filter(f => f.status === "online").length === 0 ? (
                  <div className="flex flex-col items-center justify-center p-8 text-center">
                    <UserCheck className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No friends online</h3>
                    <p className="text-sm text-muted-foreground max-w-md mb-4">
                      None of your friends are currently online
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredFriends.filter(f => f.status === "online").map((friend) => (
                      <div key={friend.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                        <div className="flex items-center">
                          <div className="relative">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={friend.avatar} />
                              <AvatarFallback className="bg-primary text-primary-foreground">
                                {friend.displayName.substring(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background bg-green-500" />
                          </div>
                          <div className="ml-3">
                            <div className="flex items-center">
                              <p className="font-medium">{friend.displayName}</p>
                              <span className="text-xs text-muted-foreground ml-2">@{friend.username}</span>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {friend.statusText || "Online"}
                            </p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Link href={`/dashboard/chat/${friend.id}`}>
                            <Button variant="ghost" size="icon">
                              <MessageSquare className="h-4 w-4" />
                            </Button>
                          </Link>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="pending" className="flex-1 p-0 m-0">
            <ScrollArea className="h-full">
              <div className="p-4">
                {incomingRequests.length === 0 && outgoingRequests.length === 0 ? (
                  <div className="flex flex-col items-center justify-center p-8 text-center">
                    <UserPlus className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No pending requests</h3>
                    <p className="text-sm text-muted-foreground max-w-md mb-4">
                      You don't have any pending friend requests
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {incomingRequests.length > 0 && (
                      <div>
                        <h3 className="font-medium text-sm mb-3 flex items-center">
                          <span>Incoming Requests</span>
                          <Badge className="ml-2" variant="secondary">{incomingRequests.length}</Badge>
                        </h3>
                        <div className="space-y-2">
                          {incomingRequests.map((request) => (
                            <div key={request.id} className="flex items-center justify-between p-3 rounded-lg bg-muted">
                              <div className="flex items-center">
                                <Avatar className="h-10 w-10">
                                  <AvatarImage src={request.avatar} />
                                  <AvatarFallback className="bg-primary text-primary-foreground">
                                    {request.displayName.substring(0, 2).toUpperCase()}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="ml-3">
                                  <div className="flex items-center">
                                    <p className="font-medium">{request.displayName}</p>
                                    <span className="text-xs text-muted-foreground ml-2">@{request.username}</span>
                                  </div>
                                  <p className="text-xs text-muted-foreground">
                                    Sent you a friend request {request.sentAt}
                                  </p>
                                </div>
                              </div>
                              <div className="flex space-x-2">
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  onClick={() => handleAcceptRequest(request)}
                                >
                                  <UserCheck className="h-4 w-4 mr-2" />
                                  Accept
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleRejectRequest(request)}
                                >
                                  <UserX className="h-4 w-4 mr-2" />
                                  Reject
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {outgoingRequests.length > 0 && (
                      <div>
                        <h3 className="font-medium text-sm mb-3 flex items-center">
                          <span>Outgoing Requests</span>
                          <Badge className="ml-2" variant="secondary">{outgoingRequests.length}</Badge>
                        </h3>
                        <div className="space-y-2">
                          {outgoingRequests.map((request) => (
                            <div key={request.id} className="flex items-center justify-between p-3 rounded-lg bg-muted">
                              <div className="flex items-center">
                                <Avatar className="h-10 w-10">
                                  <AvatarImage src={request.avatar} />
                                  <AvatarFallback className="bg-primary text-primary-foreground">
                                    {request.displayName.substring(0, 2).toUpperCase()}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="ml-3">
                                  <div className="flex items-center">
                                    <p className="font-medium">{request.displayName}</p>
                                    <span className="text-xs text-muted-foreground ml-2">@{request.username}</span>
                                  </div>
                                  <p className="text-xs text-muted-foreground">
                                    You sent a friend request {request.sentAt}
                                  </p>
                                </div>
                              </div>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleCancelRequest(request)}
                              >
                                <UserX className="h-4 w-4 mr-2" />
                                Cancel
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}