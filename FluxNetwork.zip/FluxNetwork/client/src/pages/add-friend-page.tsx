import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { sendFriendRequest } from "@/lib/auth";
import { useAuth } from "@/context/AuthContext";
import { Loader2, UserPlus, Users, AtSign, Search, UserRound } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { doc, getDoc, collection, query, where, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useBlockedUsers } from "@/context/BlockedUsersContext";

export default function AddFriendPage() {
  const [username, setUsername] = useState("");
  const [userId, setUserId] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<{
    id: string;
    username: string;
    displayName: string;
    avatarUrl?: string;
  } | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  const { isUserBlocked } = useBlockedUsers();

  const handleSendRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username.trim()) {
      toast({
        title: "Error",
        description: "Please enter a username",
        variant: "destructive"
      });
      return;
    }

    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to send friend requests",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      await sendFriendRequest(user.uid, username.trim());
      
      toast({
        title: "Friend Request Sent",
        description: `Friend request sent to ${username}`,
      });
      
      setUsername("");
      setSearchResult(null);
    } catch (error: any) {
      console.error("Error sending friend request:", error);
      
      toast({
        title: "Error",
        description: error.message || "Failed to send friend request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearchById = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!userId.trim()) {
      toast({
        title: "Error",
        description: "Please enter a user ID",
        variant: "destructive"
      });
      return;
    }

    setIsSearching(true);
    setSearchResult(null);

    try {
      // First try to get the user directly by ID
      const userDocRef = doc(db, "users", userId.trim());
      const userDoc = await getDoc(userDocRef);
      
      if (userDoc.exists()) {
        const userData = userDoc.data();
        setSearchResult({
          id: userDoc.id,
          username: userData.username || "",
          displayName: userData.displayName || "",
          avatarUrl: userData.avatarUrl
        });
      } else {
        toast({
          title: "User Not Found",
          description: "No user found with that ID. Please check the ID and try again.",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      console.error("Error searching for user:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to search for user. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleSendRequestToSearchResult = async () => {
    if (!searchResult || !user) return;
    
    setIsLoading(true);
    
    try {
      await sendFriendRequest(user.uid, searchResult.username);
      
      toast({
        title: "Friend Request Sent",
        description: `Friend request sent to ${searchResult.displayName}`,
      });
      
      setUserId("");
      setSearchResult(null);
    } catch (error: any) {
      console.error("Error sending friend request:", error);
      
      toast({
        title: "Error",
        description: error.message || "Failed to send friend request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AppLayout>
      <div className="container py-6 max-w-2xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight flex items-center">
            <Users className="mr-2 h-8 w-8" />
            Add a Friend
          </h1>
          <p className="text-muted-foreground mt-1">
            Send friend requests to connect with other users
          </p>
        </div>

        <Tabs defaultValue="username" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="username" className="flex items-center gap-2">
              <AtSign className="h-4 w-4" />
              <span>By Username</span>
            </TabsTrigger>
            <TabsTrigger value="id" className="flex items-center gap-2">
              <UserRound className="h-4 w-4" />
              <span>By Account ID</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Username Tab */}
          <TabsContent value="username">
            <Card>
              <CardHeader>
                <CardTitle>Find by Username</CardTitle>
                <CardDescription>
                  Enter a username to send a friend request
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSendRequest} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <div className="flex gap-2">
                      <Input
                        id="username"
                        placeholder="Enter username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        disabled={isLoading}
                      />
                      <Button type="submit" disabled={isLoading || !username.trim()}>
                        {isLoading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Sending...
                          </>
                        ) : (
                          <>
                            <UserPlus className="mr-2 h-4 w-4" />
                            Send Request
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </form>
              </CardContent>
              <CardFooter className="flex-col items-start border-t pt-6">
                <Alert variant="default" className="bg-muted">
                  <UserPlus className="h-4 w-4" />
                  <AlertTitle>Friend Request Tips</AlertTitle>
                  <AlertDescription className="text-sm text-muted-foreground">
                    <ul className="list-disc list-inside space-y-1 mt-2">
                      <li>Make sure the username is spelled correctly</li>
                      <li>You cannot send requests to users who already have a pending request from you</li>
                      <li>You cannot send friend requests to yourself</li>
                      <li>Friend requests can be managed in the Friends tab</li>
                    </ul>
                  </AlertDescription>
                </Alert>
              </CardFooter>
            </Card>
          </TabsContent>
          
          {/* Account ID Tab */}
          <TabsContent value="id">
            <Card>
              <CardHeader>
                <CardTitle>Find by Account ID</CardTitle>
                <CardDescription>
                  Search for a user by their unique account ID
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <form onSubmit={handleSearchById} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="userId">Account ID</Label>
                    <div className="flex gap-2">
                      <Input
                        id="userId"
                        placeholder="Enter account ID"
                        value={userId}
                        onChange={(e) => setUserId(e.target.value)}
                        disabled={isSearching}
                      />
                      <Button type="submit" disabled={isSearching || !userId.trim()} variant="secondary">
                        {isSearching ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Searching...
                          </>
                        ) : (
                          <>
                            <Search className="mr-2 h-4 w-4" />
                            Search
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </form>
                
                {searchResult && (
                  <div className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={searchResult.avatarUrl} />
                        <AvatarFallback>{searchResult.displayName.charAt(0).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="space-y-1">
                        <h3 className="font-medium text-base leading-none">{searchResult.displayName}</h3>
                        <p className="text-sm text-muted-foreground">@{searchResult.username}</p>
                      </div>
                    </div>
                    
                    <Button 
                      className="w-full" 
                      onClick={handleSendRequestToSearchResult}
                      disabled={isLoading || (searchResult.id === user?.uid) || isUserBlocked(searchResult.id)}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <UserPlus className="mr-2 h-4 w-4" />
                          Send Friend Request
                        </>
                      )}
                    </Button>
                    
                    {searchResult.id === user?.uid && (
                      <Alert variant="destructive">
                        <AlertTitle>Cannot send request</AlertTitle>
                        <AlertDescription>You cannot send a friend request to yourself.</AlertDescription>
                      </Alert>
                    )}
                    
                    {isUserBlocked(searchResult.id) && (
                      <Alert variant="destructive">
                        <AlertTitle>User is blocked</AlertTitle>
                        <AlertDescription>This user is currently blocked. Unblock them in Settings to send a friend request.</AlertDescription>
                      </Alert>
                    )}
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex-col items-start border-t pt-6">
                <Alert variant="default" className="bg-muted">
                  <Search className="h-4 w-4" />
                  <AlertTitle>Account ID Search</AlertTitle>
                  <AlertDescription className="text-sm text-muted-foreground">
                    <ul className="list-disc list-inside space-y-1 mt-2">
                      <li>Account IDs are unique identifiers for each user</li>
                      <li>Users can share their Account ID to make it easier to find them</li>
                      <li>Account IDs allow you to find users with common usernames</li>
                      <li>The Account ID search is case-sensitive</li>
                    </ul>
                  </AlertDescription>
                </Alert>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}