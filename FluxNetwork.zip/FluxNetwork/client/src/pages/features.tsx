import { useState } from "react";
import { motion } from "framer-motion";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Check, Clock, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

// Define roadmap feature types
type FeatureStatus = "completed" | "inProgress" | "upcoming";

interface Feature {
  name: string;
  description: string;
  status: FeatureStatus;
  icon?: React.ReactNode;
}

export default function FeaturesPage() {
  const [selectedTab, setSelectedTab] = useState<"all" | FeatureStatus>("all");
  
  const features: Feature[] = [
    {
      name: "Calling",
      description: "Voice and video calls with friends and group members",
      status: "completed",
      icon: <Check className="h-4 w-4" />
    },
    {
      name: "Friends",
      description: "Add friends, see their status, and chat directly",
      status: "completed",
      icon: <Check className="h-4 w-4" />
    },
    {
      name: "Messages",
      description: "Send text, images, videos, and other files to friends and rooms",
      status: "completed",
      icon: <Check className="h-4 w-4" />
    },
    {
      name: "Rooms",
      description: "Create and join rooms to chat with multiple people",
      status: "completed",
      icon: <Check className="h-4 w-4" />
    },
    {
      name: "Groups",
      description: "Create and manage groups of friends for easier communication",
      status: "completed",
      icon: <Check className="h-4 w-4" />
    },
    {
      name: "Profile Pictures",
      description: "Customize your profile with unique avatars",
      status: "completed",
      icon: <Check className="h-4 w-4" />
    },
    {
      name: "Custom Emojis",
      description: "Create and use your own custom emojis in chats",
      status: "upcoming",
      icon: <Clock className="h-4 w-4" />
    },
    {
      name: "Bots",
      description: "Create and add bots to automate tasks and enhance your experience",
      status: "upcoming",
      icon: <Clock className="h-4 w-4" />
    },
    {
      name: "Built-in AI",
      description: "AI-powered features for smarter communication",
      status: "upcoming",
      icon: <Clock className="h-4 w-4" />
    }
  ];

  const filteredFeatures = selectedTab === "all" 
    ? features 
    : features.filter(feature => feature.status === selectedTab);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero section */}
        <section className="bg-gradient-to-r from-primary/10 via-primary/5 to-background pt-20 pb-16">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center text-center space-y-4">
              <h1 className="text-3xl md:text-5xl font-bold tracking-tighter">
                Flux Features
              </h1>
              <p className="text-muted-foreground md:text-xl max-w-[800px]">
                Explore what Flux has to offer and what's coming next in our development roadmap.
              </p>
            </div>
          </div>
        </section>

        {/* Roadmap section */}
        <section className="py-16 px-4 md:px-6">
          <div className="container">
            <div className="mb-12 text-center">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Feature Roadmap</h2>
              <p className="text-muted-foreground max-w-[800px] mx-auto">
                Track our progress as we build the future of communication. See what's already available
                and what exciting features are coming soon.
              </p>
            </div>

            {/* Filter tabs */}
            <div className="flex justify-center mb-10">
              <div className="inline-flex p-1 bg-muted rounded-lg">
                <Button 
                  variant={selectedTab === "all" ? "default" : "ghost"}
                  onClick={() => setSelectedTab("all")}
                  className="rounded-md"
                >
                  All
                </Button>
                <Button 
                  variant={selectedTab === "completed" ? "default" : "ghost"}
                  onClick={() => setSelectedTab("completed")}
                  className="rounded-md"
                >
                  Completed
                </Button>
                <Button 
                  variant={selectedTab === "upcoming" ? "default" : "ghost"}
                  onClick={() => setSelectedTab("upcoming")}
                  className="rounded-md"
                >
                  Upcoming
                </Button>
              </div>
            </div>

            {/* Features grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredFeatures.map((feature, index) => (
                <motion.div
                  key={feature.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Card className={`h-full transition-colors hover:border-primary ${
                    feature.status === "completed" ? "border-green-500/30" : 
                    feature.status === "upcoming" ? "border-amber-500/30" : ""
                  }`}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-xl">{feature.name}</CardTitle>
                        <Badge variant={
                          feature.status === "completed" ? "default" : 
                          feature.status === "upcoming" ? "outline" : 
                          "secondary"
                        }>
                          <span className="flex items-center gap-1">
                            {feature.icon}
                            {feature.status === "completed" ? "Available" : "Coming Soon"}
                          </span>
                        </Badge>
                      </div>
                      <CardDescription>{feature.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {feature.status === "upcoming" && (
                        <p className="text-sm text-muted-foreground">We're actively working on this feature.</p>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Why Flux section */}
        <section className="py-16 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold tracking-tight mb-4">Why Choose Flux?</h2>
                <p className="text-muted-foreground mb-6">
                  We're building Flux with user experience and privacy in mind, offering a modern alternative
                  to existing communication platforms without the price gouging.
                </p>
                <ul className="space-y-4">
                  <li className="flex gap-3">
                    <Check className="h-6 w-6 text-green-500 flex-shrink-0" />
                    <div>
                      <h3 className="font-medium">User-First Approach</h3>
                      <p className="text-sm text-muted-foreground">We prioritize your needs over corporate profits</p>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <Check className="h-6 w-6 text-green-500 flex-shrink-0" />
                    <div>
                      <h3 className="font-medium">Beautiful Design</h3>
                      <p className="text-sm text-muted-foreground">Modern, intuitive interface that's a pleasure to use</p>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <Check className="h-6 w-6 text-green-500 flex-shrink-0" />
                    <div>
                      <h3 className="font-medium">Fair Pricing</h3>
                      <p className="text-sm text-muted-foreground">Generous free tier with reasonable premium options</p>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <Check className="h-6 w-6 text-green-500 flex-shrink-0" />
                    <div>
                      <h3 className="font-medium">Continuous Improvement</h3>
                      <p className="text-sm text-muted-foreground">We're constantly adding new features based on feedback</p>
                    </div>
                  </li>
                </ul>
                <div className="mt-8">
                  <Button className="gap-2">
                    Get Started <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="bg-gradient-to-br from-primary/20 to-primary/5 p-8 rounded-2xl">
                <div className="aspect-video bg-card rounded-lg shadow-lg flex items-center justify-center">
                  <div className="text-center p-8">
                    <h3 className="text-xl font-semibold mb-2">Feature Demo</h3>
                    <p className="text-muted-foreground mb-4">Video demonstration coming soon</p>
                    <Button variant="outline">Notify Me</Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}