import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  CreditCard, 
  Shield, 
  User, 
  Mail, 
  Upload, 
  Lock,
  Crown,
  Zap
} from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Link } from "wouter";

export default function AccountPage() {
  const { user, userProfile, refreshUserProfile } = useAuth();
  const { toast } = useToast();
  const [displayName, setDisplayName] = useState(userProfile?.displayName || user?.displayName || "");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  
  const [isUpdating, setIsUpdating] = useState(false);
  // Using any because these might be custom properties in Firebase not defined in our schema
  const [pronouns, setPronouns] = useState((userProfile as any)?.pronouns || "");
  const [bio, setBio] = useState((userProfile as any)?.bio || "");
  const [avatarUrl, setAvatarUrl] = useState(userProfile?.avatarUrl || "");

  const handleProfileUpdate = async () => {
    if (!user) return;
    
    setIsUpdating(true);
    
    try {
      // Import Firebase functions from your lib/firebase.ts
      const { doc, updateDoc } = await import("firebase/firestore");
      const { firestore } = await import("@/lib/firebase");
      
      const userDocRef = doc(firestore, "users", user.uid);
      
      await updateDoc(userDocRef, {
        displayName,
        pronouns,
        bio,
        avatarUrl,
        updatedAt: new Date()
      });
      
      // Refresh the profile data through the context
      if (refreshUserProfile) {
        await refreshUserProfile();
      }
      
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
    } catch (error) {
      console.error("Error updating profile:", error);
      toast({
        title: "Error",
        description: "Failed to update your profile. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsUpdating(false);
    }
  };
  
  const handlePasswordChange = () => {
    if (newPassword !== confirmPassword) {
      toast({
        title: "Error",
        description: "New passwords do not match.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Password Updated",
      description: "Your password has been changed successfully.",
    });
    
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  return (
    <AppLayout>
      <div className="container py-6 max-w-5xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight">Account Settings</h1>
          <p className="text-muted-foreground mt-1">
            Manage your account details, security and subscription
          </p>
        </div>
        
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="profile" className="flex items-center">
              <User className="h-4 w-4 mr-2" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center">
              <Shield className="h-4 w-4 mr-2" />
              Security
            </TabsTrigger>
            <TabsTrigger value="subscription" className="flex items-center">
              <CreditCard className="h-4 w-4 mr-2" />
              Subscription
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="profile">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                  <CardDescription>
                    Update your account details and public profile
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-1">
                    <Label htmlFor="username">Username</Label>
                    <Input 
                      id="username" 
                      value={userProfile?.username || "username"} 
                      disabled 
                    />
                    <p className="text-xs text-muted-foreground">
                      Your username cannot be changed after account creation
                    </p>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="displayName">Display Name</Label>
                    <Input 
                      id="displayName" 
                      value={displayName} 
                      onChange={(e) => setDisplayName(e.target.value)} 
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      value={userProfile?.email || user?.email || ""} 
                      disabled={!!user?.email}
                    />
                    {user?.email && (
                      <p className="text-xs text-muted-foreground">
                        Email is managed through your authentication provider
                      </p>
                    )}
                  </div>
                  
                  <div className="space-y-1">
                    <Label htmlFor="pronouns">Pronouns</Label>
                    <Input 
                      id="pronouns" 
                      value={pronouns} 
                      onChange={(e) => setPronouns(e.target.value)} 
                      placeholder="e.g. they/them, she/her, he/him"
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <Label htmlFor="bio">Bio</Label>
                    <Input 
                      id="bio" 
                      value={bio} 
                      onChange={(e) => setBio(e.target.value)} 
                      placeholder="Tell others about yourself"
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleProfileUpdate}>Save Changes</Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Avatar</CardTitle>
                  <CardDescription>
                    Upload a picture to personalize your profile
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-col items-center justify-center space-y-3">
                    <Avatar className="h-24 w-24">
                      <AvatarImage src={userProfile?.avatarUrl || ""} />
                      <AvatarFallback className="text-2xl bg-primary text-primary-foreground">
                        {displayName.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    
                    <Button variant="outline" className="mt-4">
                      <Upload className="h-4 w-4 mr-2" />
                      Upload New Avatar
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">
                      Recommended size: 256x256px. Max size: 2MB.
                      Supported formats: JPEG, PNG, GIF
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Password Change</CardTitle>
                <CardDescription>
                  Update your password to maintain account security
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1">
                  <Label htmlFor="currentPassword">Current Password</Label>
                  <Input 
                    id="currentPassword" 
                    type="password" 
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="newPassword">New Password</Label>
                  <Input 
                    id="newPassword" 
                    type="password" 
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="confirmPassword">Confirm New Password</Label>
                  <Input 
                    id="confirmPassword" 
                    type="password" 
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={handlePasswordChange}
                  disabled={!currentPassword || !newPassword || !confirmPassword}
                >
                  <Lock className="h-4 w-4 mr-2" />
                  Change Password
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="subscription">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Current Plan</CardTitle>
                  <CardDescription>
                    Your current subscription and benefits
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4 pb-4 border-b border-border">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                          <Zap className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold">Free Plan</h3>
                          <p className="text-sm text-muted-foreground">Basic features</p>
                        </div>
                      </div>
                      <span className="text-sm font-medium">Current</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Includes basic messaging, 10 friends limit, and 5 rooms maximum.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Upgrade to unlock:</h4>
                    <ul className="space-y-1">
                      <li className="text-sm flex items-center">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary mr-2"></span>
                        Unlimited friends
                      </li>
                      <li className="text-sm flex items-center">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary mr-2"></span>
                        Unlimited rooms
                      </li>
                      <li className="text-sm flex items-center">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary mr-2"></span>
                        Custom themes and appearance
                      </li>
                      <li className="text-sm flex items-center">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary mr-2"></span>
                        Enhanced privacy features
                      </li>
                    </ul>
                  </div>
                </CardContent>
                <CardFooter>
                  <Link href="/pricing">
                    <Button variant="outline" className="w-full">
                      View Available Plans
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Upgrade Now</CardTitle>
                  <CardDescription>
                    Choose a plan that fits your needs
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup defaultValue="free" className="space-y-4">
                    <div className="flex items-center space-x-2 rounded-md border border-border p-3">
                      <RadioGroupItem value="free" id="free" />
                      <Label htmlFor="free" className="flex-1 flex justify-between cursor-pointer">
                        <div>
                          <p className="font-medium">Free</p>
                          <p className="text-sm text-muted-foreground">Basic features</p>
                        </div>
                        <div className="font-medium">$0</div>
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-2 rounded-md border border-border p-3">
                      <RadioGroupItem value="glow" id="glow" />
                      <Label htmlFor="glow" className="flex-1 flex justify-between cursor-pointer">
                        <div className="flex items-center">
                          <div>
                            <p className="font-medium">Glow</p>
                            <p className="text-sm text-muted-foreground">One-time upgrade</p>
                          </div>
                          <Zap className="h-4 w-4 text-yellow-500 ml-2" />
                        </div>
                        <div className="font-medium">$5</div>
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-2 rounded-md border border-primary p-3 bg-primary/5">
                      <RadioGroupItem value="echo" id="echo" />
                      <Label htmlFor="echo" className="flex-1 flex justify-between cursor-pointer">
                        <div className="flex items-center">
                          <div>
                            <p className="font-medium">Echo</p>
                            <p className="text-sm text-muted-foreground">Premium support</p>
                          </div>
                          <Crown className="h-4 w-4 text-yellow-500 ml-2" />
                        </div>
                        <div className="font-medium">$5/mo</div>
                      </Label>
                    </div>
                  </RadioGroup>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Upgrade Plan
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}