import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { AtSign, Book, HelpCircle, MessageSquare } from "lucide-react";

export default function SupportPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero section */}
        <section className="bg-gradient-to-r from-primary/10 via-primary/5 to-background pt-20 pb-16">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center text-center space-y-4">
              <h1 className="text-3xl md:text-5xl font-bold tracking-tighter">
                How Can We Help?
              </h1>
              <p className="text-muted-foreground md:text-xl max-w-[800px]">
                We're here to assist you with any questions or issues you might have.
              </p>
            </div>
          </div>
        </section>

        {/* Support options */}
        <section className="py-16 px-4 md:px-6">
          <div className="container">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
              <Card className="flex flex-col h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Book className="h-5 w-5 text-primary" />
                    Documentation
                  </CardTitle>
                  <CardDescription>
                    Browse through our comprehensive guides and tutorials
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-muted-foreground mb-4">
                    Find answers to common questions and learn how to use all Flux features.
                  </p>
                  <Button variant="outline" className="w-full">View Documentation</Button>
                </CardContent>
              </Card>

              <Card className="flex flex-col h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-primary" />
                    Community Forums
                  </CardTitle>
                  <CardDescription>
                    Connect with other users and share your experiences
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-muted-foreground mb-4">
                    Join discussions, ask questions, and learn from the community.
                  </p>
                  <Button variant="outline" className="w-full">Visit Forums</Button>
                </CardContent>
              </Card>

              <Card className="flex flex-col h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <HelpCircle className="h-5 w-5 text-primary" />
                    FAQ
                  </CardTitle>
                  <CardDescription>
                    Quick answers to the most common questions
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-muted-foreground mb-4">
                    Find immediate answers to frequently asked questions about Flux.
                  </p>
                  <Button variant="outline" className="w-full">View FAQ</Button>
                </CardContent>
              </Card>
            </div>

            {/* Contact form */}
            <div className="max-w-3xl mx-auto border rounded-lg p-6 bg-card">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold mb-2">Contact Support</h2>
                <p className="text-muted-foreground">
                  Need more help? Send us a message and we'll get back to you as soon as possible.
                </p>
              </div>
              
              <form className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium">
                      Name
                    </label>
                    <Input id="name" placeholder="Your name" />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      Email
                    </label>
                    <div className="relative">
                      <AtSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                      <Input id="email" type="email" placeholder="email@example.com" className="pl-10" />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-medium">
                    Subject
                  </label>
                  <Input id="subject" placeholder="What's your inquiry about?" />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    Message
                  </label>
                  <Textarea id="message" placeholder="Describe your issue or question in detail" rows={5} />
                </div>
                
                <Button className="w-full md:w-auto">Send Message</Button>
              </form>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}