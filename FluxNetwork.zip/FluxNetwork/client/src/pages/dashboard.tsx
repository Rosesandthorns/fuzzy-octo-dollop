import { useState, useEffect } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { MessageSquare, Users, Grid3X3, Plus, Loader2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getFriends, getFriendRequests } from "@/lib/auth";
import { Friend } from "@/lib/auth";

export default function Dashboard() {
  const { user, userProfile } = useAuth();
  const { toast } = useToast();
  const displayName = userProfile?.displayName || user?.displayName || "User";
  const [friends, setFriends] = useState<Friend[]>([]);
  const [friendRequests, setFriendRequests] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);

  // Load friends and requests from Firestore
  useEffect(() => {
    const loadUserData = async () => {
      if (!user) return;
      
      try {
        setIsLoading(true);
        // Get friends data
        const friendsData = await getFriends(user.uid);
        setFriends(friendsData);
        
        // Get friend requests
        const requestsData = await getFriendRequests(user.uid);
        setFriendRequests(requestsData);
        
        // We'll leave the activity empty for now as we don't have a proper
        // activity log system yet. This will be populated from real data later.
        setRecentActivity([]);
      } catch (error) {
        console.error("Error loading user data:", error);
        toast({
          title: "Error",
          description: "Failed to load your data. Please try again later.",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    loadUserData();
  }, [user, toast]);

  // Get online friends
  const onlineFriends = friends.filter(friend => friend.status === "online");

  return (
    <AppLayout>
      <div className="p-6 max-w-5xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight">Welcome, {displayName}!</h1>
          <p className="text-muted-foreground mt-1">
            Here's what's happening in your Flux world
          </p>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-primary"/>
            <span className="ml-2">Loading your data...</span>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <MessageSquare className="h-5 w-5 mr-2 text-primary" />
                    Messages
                  </CardTitle>
                  <CardDescription>Your conversations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-muted-foreground">Unread messages</div>
                      <div className="font-medium">0</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-muted-foreground">Active chats</div>
                      <div className="font-medium">{friends.length}</div>
                    </div>
                    <Link href="/dashboard/messages">
                      <Button className="w-full mt-2" variant="outline">View Messages</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <Users className="h-5 w-5 mr-2 text-primary" />
                    Friends
                  </CardTitle>
                  <CardDescription>Your connections</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-muted-foreground">Friends online</div>
                      <div className="font-medium">{onlineFriends.length}</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-muted-foreground">Pending requests</div>
                      <div className="font-medium">{friendRequests.length}</div>
                    </div>
                    <Link href="/dashboard/friends">
                      <Button className="w-full mt-2" variant="outline">Manage Friends</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <Grid3X3 className="h-5 w-5 mr-2 text-primary" />
                    Rooms
                  </CardTitle>
                  <CardDescription>Your communities</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-muted-foreground">Active rooms</div>
                      <div className="font-medium">0</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-muted-foreground">Notifications</div>
                      <div className="font-medium">0</div>
                    </div>
                    <Link href="/dashboard/create-room">
                      <Button className="w-full mt-2" variant="outline">Create Room</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>

            {recentActivity.length > 0 ? (
              <div className="mb-6">
                <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
                <Card>
                  <CardContent className="p-0">
                    <div className="divide-y divide-border">
                      {recentActivity.map((activity, index) => (
                        <div key={index} className="p-4 flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                              {activity.type === "message" && <MessageSquare className="h-4 w-4 text-primary" />}
                              {activity.type === "friend" && <Users className="h-4 w-4 text-primary" />}
                              {activity.type === "room" && <Grid3X3 className="h-4 w-4 text-primary" />}
                            </div>
                            <div>
                              <p className="text-sm font-medium">{activity.content}</p>
                              <p className="text-xs text-muted-foreground">{activity.time}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <div className="mb-6">
                <Card className="p-6">
                  <div className="text-center">
                    <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                    <h3 className="text-lg font-medium mb-2">No Recent Activity</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Your activity will appear here as you interact with friends and rooms.
                    </p>
                  </div>
                </Card>
              </div>
            )}

            <div>
              <h2 className="text-xl font-semibold mb-4">Online Friends</h2>
              {onlineFriends.length > 0 ? (
                <div className="flex flex-wrap gap-4">
                  {onlineFriends.map(friend => (
                    <div key={friend.id} className="flex flex-col items-center">
                      <Avatar className="h-12 w-12 mb-2">
                        <AvatarImage src={friend.avatar} />
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {friend.displayName.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{friend.displayName}</span>
                      <span className="text-xs text-muted-foreground">{friend.statusText || "Online"}</span>
                    </div>
                  ))}
                  <Link href="/dashboard/friends">
                    <Button variant="outline" className="h-12 w-12 rounded-full mb-2" size="icon">
                      <Plus className="h-5 w-5" />
                    </Button>
                    <div className="text-sm text-center">Add</div>
                  </Link>
                </div>
              ) : (
                <div className="flex flex-col items-center p-8 text-center">
                  <Users className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No friends online</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Add some friends to see when they're online
                  </p>
                  <Link href="/dashboard/friends">
                    <Button>Add Friends</Button>
                  </Link>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </AppLayout>
  );
}
