import { useState, useEffect } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import { Loader2, Users2, Hash, Lock, Check, X, Shield } from "lucide-react";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useLocation } from "wouter";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { firestore } from "@/lib/firebase";
import { getFriends, Friend } from "@/lib/auth";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type RoomType = "public" | "private" | "restricted";

export default function CreateRoomPage() {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [roomType, setRoomType] = useState<RoomType>("public");
  const [isLoading, setIsLoading] = useState(false);
  const [invitesEnabled, setInvitesEnabled] = useState(true);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [selectedFriends, setSelectedFriends] = useState<string[]>([]);
  const { toast } = useToast();
  const { user } = useAuth();
  const [_, setLocation] = useLocation();

  // Load friends for invitation
  useEffect(() => {
    const loadFriends = async () => {
      if (user?.uid) {
        try {
          const friendsList = await getFriends(user.uid);
          setFriends(friendsList);
        } catch (error) {
          console.error("Error loading friends:", error);
        }
      }
    };

    loadFriends();
  }, [user]);

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast({
        title: "Error",
        description: "Please enter a room name",
        variant: "destructive"
      });
      return;
    }

    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to create a room",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      // Create room document in Firestore
      const roomData = {
        name: name.trim(),
        description: description.trim(),
        type: roomType,
        ownerId: user.uid,
        invitesEnabled,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        members: [user.uid],
        // Add initial members if private room
        ...(roomType === "private" && { invitedMembers: selectedFriends }),
      };

      const roomRef = await addDoc(collection(firestore, "rooms"), roomData);
      
      toast({
        title: "Room Created",
        description: `${name} has been created successfully`,
      });
      
      // Navigate to the new room
      setLocation(`/dashboard/room/${roomRef.id}`);
    } catch (error: any) {
      console.error("Error creating room:", error);
      
      toast({
        title: "Error",
        description: error.message || "Failed to create room. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectFriend = (friendId: string) => {
    if (selectedFriends.includes(friendId)) {
      setSelectedFriends(selectedFriends.filter(id => id !== friendId));
    } else {
      setSelectedFriends([...selectedFriends, friendId]);
    }
  };

  return (
    <AppLayout>
      <div className="container py-6 max-w-2xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight flex items-center">
            <Hash className="mr-2 h-8 w-8" />
            Create a Room
          </h1>
          <p className="text-muted-foreground mt-1">
            Create a new space to chat with friends
          </p>
        </div>

        <Card>
          <form onSubmit={handleCreateRoom}>
            <CardHeader>
              <CardTitle>Room Details</CardTitle>
              <CardDescription>
                Customize your new room
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Room Name</Label>
                <Input
                  id="name"
                  placeholder="Enter room name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  disabled={isLoading}
                  maxLength={50}
                />
                <p className="text-xs text-muted-foreground">
                  {name.length}/50 characters
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Enter room description (optional)"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={isLoading}
                  maxLength={200}
                  rows={3}
                />
                <p className="text-xs text-muted-foreground">
                  {description.length}/200 characters
                </p>
              </div>
              
              <div className="space-y-2">
                <Label>Room Type</Label>
                <RadioGroup 
                  value={roomType} 
                  onValueChange={(value) => setRoomType(value as RoomType)}
                  className="space-y-3"
                >
                  <div className="flex items-start space-x-2 rounded-md border p-3">
                    <RadioGroupItem value="public" id="public" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="public" className="flex items-center text-base font-medium">
                        <Users2 className="mr-2 h-4 w-4 text-primary" />
                        Public
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        Anyone can join and view this room
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-2 rounded-md border p-3">
                    <RadioGroupItem value="restricted" id="restricted" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="restricted" className="flex items-center text-base font-medium">
                        <Shield className="mr-2 h-4 w-4 text-primary" />
                        Restricted
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        Anyone can see this room, but users need approval to join
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-2 rounded-md border p-3">
                    <RadioGroupItem value="private" id="private" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="private" className="flex items-center text-base font-medium">
                        <Lock className="mr-2 h-4 w-4 text-primary" />
                        Private
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        Only invited users can see and join this room
                      </p>
                    </div>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="flex items-center justify-between border-t pt-4">
                <div className="space-y-0.5">
                  <Label htmlFor="invites">Allow Invites</Label>
                  <p className="text-sm text-muted-foreground">
                    Let members invite others to this room
                  </p>
                </div>
                <Switch
                  id="invites"
                  checked={invitesEnabled}
                  onCheckedChange={setInvitesEnabled}
                  disabled={isLoading}
                />
              </div>
              
              {roomType === "private" && (
                <div className="space-y-4 border-t pt-4">
                  <Label>Invite Friends</Label>
                  {friends.length > 0 ? (
                    <div className="space-y-2">
                      {friends.map(friend => (
                        <div 
                          key={friend.id}
                          className="flex items-center justify-between p-2 rounded-md hover:bg-muted cursor-pointer"
                          onClick={() => handleSelectFriend(friend.id)}
                        >
                          <div className="flex items-center">
                            <div className={`h-3 w-3 rounded-full mr-2 ${
                              friend.status === 'online' ? 'bg-green-500' : 
                              friend.status === 'idle' ? 'bg-yellow-500' : 'bg-gray-500'
                            }`} />
                            <span>{friend.displayName || friend.username}</span>
                          </div>
                          <div className="flex items-center justify-center h-6 w-6 rounded-full border">
                            {selectedFriends.includes(friend.id) ? (
                              <Check className="h-4 w-4 text-primary" />
                            ) : (
                              <X className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100" />
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground italic">
                      You don't have any friends to invite yet
                    </p>
                  )}
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-end border-t pt-4">
              <Button 
                type="submit" 
                disabled={isLoading || !name.trim()}
                className="w-full sm:w-auto"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Hash className="mr-2 h-4 w-4" />
                    Create Room
                  </>
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </AppLayout>
  );
}