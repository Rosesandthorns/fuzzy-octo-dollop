import { useState, useEffect } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, Plus, MessageSquare, Users, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { getFriends, Friend } from "@/lib/auth";

interface ChatPreview {
  id: string;
  name: string;
  avatar?: string;
  lastMessage: string;
  time: string;
  unread: number;
  online: boolean;
  isRoom?: boolean;
}

export default function MessagesPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [rooms, setRooms] = useState<ChatPreview[]>([]);
  
  // Load friends data
  useEffect(() => {
    const loadData = async () => {
      if (!user) return;
      
      try {
        setIsLoading(true);
        const friendsData = await getFriends(user.uid);
        setFriends(friendsData);
        
        // We don't have real rooms yet, so we'll use an empty array
        setRooms([]);
      } catch (error) {
        console.error("Error loading messages data:", error);
        toast({
          title: "Error",
          description: "Failed to load your messages.",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, [user, toast]);
  
  // Map friends to direct message previews
  const directMessages: ChatPreview[] = friends.map(friend => ({
    id: friend.id,
    name: friend.displayName,
    avatar: friend.avatar,
    lastMessage: "No messages yet", // We don't have real messages yet
    time: "Never", 
    unread: 0,
    online: friend.status === "online"
  }));

  const filteredDMs = directMessages.filter(dm => 
    dm.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    dm.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredRooms = rooms.filter(room => 
    room.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    room.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleNewMessage = () => {
    toast({
      title: "New Message",
      description: "Starting a new conversation feature coming soon!",
    });
  };

  return (
    <AppLayout>
      <div className="h-full flex flex-col">
        <div className="flex-shrink-0 border-b border-border p-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">Messages</h1>
            <Button onClick={handleNewMessage}>
              <Plus className="h-4 w-4 mr-2" />
              New Message
            </Button>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search messages..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        
        <Tabs defaultValue="direct" className="flex-1 flex flex-col">
          <TabsList className="w-full">
            <TabsTrigger value="direct" className="flex-1 flex items-center justify-center">
              <Users className="h-4 w-4 mr-2" />
              Direct Messages
            </TabsTrigger>
            <TabsTrigger value="rooms" className="flex-1 flex items-center justify-center">
              <MessageSquare className="h-4 w-4 mr-2" />
              Rooms
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="direct" className="flex-1 p-0 m-0">
            <ScrollArea className="h-full">
              <div className="p-2">
                {filteredDMs.length === 0 ? (
                  <Card>
                    <CardContent className="p-6 flex flex-col items-center justify-center">
                      <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
                      <CardTitle className="text-center mb-2">No messages found</CardTitle>
                      <p className="text-center text-sm text-muted-foreground">
                        {searchQuery ? 
                          "Try a different search term or clear your search" : 
                          "Start a conversation with a friend"
                        }
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-2">
                    {filteredDMs.map((chat) => (
                      <Link key={chat.id} href={`/dashboard/chat/${chat.id}`}>
                        <div className="flex items-center p-3 rounded-lg hover:bg-muted cursor-pointer">
                          <div className="relative">
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={chat.avatar} />
                              <AvatarFallback className="bg-primary text-primary-foreground">
                                {chat.name.substring(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <span className={cn(
                              "absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background",
                              chat.online ? "bg-green-500" : "bg-gray-400"
                            )} />
                          </div>
                          <div className="ml-3 flex-1 overflow-hidden">
                            <div className="flex items-center justify-between">
                              <p className="font-medium truncate">{chat.name}</p>
                              <p className="text-xs text-muted-foreground">{chat.time}</p>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">
                              {chat.lastMessage}
                            </p>
                          </div>
                          {chat.unread > 0 && (
                            <div className="ml-2 bg-primary text-primary-foreground h-5 min-w-5 px-1 rounded-full flex items-center justify-center text-xs">
                              {chat.unread}
                            </div>
                          )}
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="rooms" className="flex-1 p-0 m-0">
            <ScrollArea className="h-full">
              <div className="p-2">
                {filteredRooms.length === 0 ? (
                  <Card>
                    <CardContent className="p-6 flex flex-col items-center justify-center">
                      <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
                      <CardTitle className="text-center mb-2">No rooms found</CardTitle>
                      <p className="text-center text-sm text-muted-foreground">
                        {searchQuery ? 
                          "Try a different search term or clear your search" : 
                          "Join or create a room to get started"
                        }
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-2">
                    {filteredRooms.map((chat) => (
                      <Link key={chat.id} href={`/dashboard/room/${chat.id}`}>
                        <div className="flex items-center p-3 rounded-lg hover:bg-muted cursor-pointer">
                          <Avatar className="h-12 w-12">
                            <AvatarFallback className="bg-primary/10 text-primary">
                              {chat.name.substring(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="ml-3 flex-1 overflow-hidden">
                            <div className="flex items-center justify-between">
                              <p className="font-medium truncate">{chat.name}</p>
                              <p className="text-xs text-muted-foreground">{chat.time}</p>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">
                              {chat.lastMessage}
                            </p>
                          </div>
                          {chat.unread > 0 && (
                            <div className="ml-2 bg-primary text-primary-foreground h-5 min-w-5 px-1 rounded-full flex items-center justify-center text-xs">
                              {chat.unread}
                            </div>
                          )}
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}