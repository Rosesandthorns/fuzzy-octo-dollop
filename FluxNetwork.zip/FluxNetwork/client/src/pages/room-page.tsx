import { useEffect, useState, useRef } from "react";
import { useLocation, useRoute } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Users, Settings, Plus, Hash } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { useWebSocketContext } from "@/context/WebSocketContext";
import { webSocketManager } from "@/lib/websocket";

interface Message {
  id: string;
  content: string;
  timestamp: string;
  sender: {
    id: string;
    name: string;
    avatar?: string;
    isCurrentUser: boolean;
  };
}

export default function RoomPage() {
  const { toast } = useToast();
  const [match, params] = useRoute<{ id: string }>("/dashboard/room/:id");
  const [, navigate] = useLocation();
  const [messageInput, setMessageInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState<{[key: string]: boolean}>({});
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { sendRoomMessage, setTypingStatus, isConnected } = useWebSocketContext();
  
  // Redirect if no match
  useEffect(() => {
    if (!match) {
      navigate("/dashboard");
    }
  }, [match, navigate]);

  // Room data - We're not using mock data anymore but fetching from the server
  const [roomData, setRoomData] = useState({
    id: params?.id || "",
    name: "Room",
    members: [
      { id: "current", name: "You", isOnline: true }
    ]
  });

  // Set up WebSocket listeners for messages
  useEffect(() => {
    // Initialize with empty messages
    setMessages([]);
    
    // Set up WebSocket listeners for real-time messaging
    const roomMessageHandler = (data: any) => {
      if (data.roomId === params?.id && !data.isCurrentUser) {
        const newMessage: Message = {
          id: Date.now().toString(),
          content: data.message,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          sender: {
            id: data.senderId,
            name: data.senderName || `User ${data.senderId}`,
            isCurrentUser: false
          }
        };
        
        setMessages(prevMessages => [...prevMessages, newMessage]);
        
        // Auto-scroll to bottom
        if (scrollAreaRef.current) {
          setTimeout(() => {
            scrollAreaRef.current?.scrollTo({
              top: scrollAreaRef.current.scrollHeight,
              behavior: 'smooth'
            });
          }, 100);
        }
      }
    };
    
    const typingHandler = (data: any) => {
      if (data.roomId === params?.id && !data.isCurrentUser) {
        setIsTyping(prev => ({
          ...prev,
          [data.senderId]: data.isTyping
        }));
      }
    };
    
    // Register WebSocket listeners
    webSocketManager.on('room_message', roomMessageHandler);
    webSocketManager.on('typing_indicator', typingHandler);
    
    // Clean up listeners on unmount
    return () => {
      webSocketManager.off('room_message', roomMessageHandler);
      webSocketManager.off('typing_indicator', typingHandler);
    };
  }, [params?.id, roomData.name]);
  
  const handleSendMessage = () => {
    if (messageInput.trim() === "" || !isConnected) return;

    // Add the new message
    const newMessage: Message = {
      id: Date.now().toString(),
      content: messageInput,
      timestamp: "Just now",
      sender: {
        id: "current",
        name: "You",
        isCurrentUser: true
      }
    };

    setMessages([...messages, newMessage]);
    
    // Send message via WebSocket
    if (params?.id) {
      sendRoomMessage(params.id, messageInput);
    }
    
    setMessageInput("");
    
    // Auto-scroll to bottom
    if (scrollAreaRef.current) {
      setTimeout(() => {
        scrollAreaRef.current?.scrollTo({
          top: scrollAreaRef.current.scrollHeight,
          behavior: 'smooth'
        });
      }, 100);
    }
  };
  
  // Handle input changes to send typing indicators
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessageInput(e.target.value);
    
    // Send typing indicator if a room is specified
    if (params?.id && isConnected) {
      setTypingStatus(params.id, e.target.value.length > 0, true);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!match) return null;

  return (
    <AppLayout>
      <div className="h-full flex flex-col">
        {/* Room header */}
        <div className="flex-shrink-0 h-14 border-b border-border flex items-center justify-between px-4">
          <div className="flex items-center">
            <div className="h-8 w-8 bg-primary/10 rounded-md flex items-center justify-center mr-3">
              <Hash className="h-5 w-5 text-primary" />
            </div>
            <h2 className="font-semibold">{roomData.name}</h2>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon">
              <Users className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Main chat area */}
          <div className="flex-1 flex flex-col">
            {/* Messages */}
            <ScrollArea className="flex-1 p-4" ref={scrollAreaRef as any}>
              <div className="space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className={cn(
                    "flex items-start",
                    message.sender.isCurrentUser ? "justify-end" : "justify-start"
                  )}>
                    {!message.sender.isCurrentUser && (
                      <Avatar className="h-8 w-8 mr-3">
                        <AvatarImage src={message.sender.avatar} />
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {message.sender.name.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    )}
                    <div className={cn(
                      "max-w-[70%] rounded-lg p-3",
                      message.sender.isCurrentUser
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    )}>
                      {!message.sender.isCurrentUser && (
                        <p className="text-xs font-medium mb-1">{message.sender.name}</p>
                      )}
                      <p className="text-sm">{message.content}</p>
                      <p className="text-xs opacity-70 mt-1 text-right">{message.timestamp}</p>
                    </div>
                    {message.sender.isCurrentUser && (
                      <Avatar className="h-8 w-8 ml-3">
                        <AvatarImage src={message.sender.avatar} />
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {message.sender.name.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                ))}
                
                {/* Typing indicators */}
                {Object.entries(isTyping).filter(([_, isTyping]) => isTyping).map(([userId]) => {
                  const member = roomData.members.find(m => m.id === userId);
                  return (
                    <div key={`typing-${userId}`} className="flex items-start ml-2 mt-2">
                      <Avatar className="h-8 w-8 mr-3">
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {member ? member.name.substring(0, 2).toUpperCase() : 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="bg-muted rounded-lg p-2 px-4">
                        <div className="flex items-center space-x-1">
                          <span className="w-2 h-2 rounded-full bg-secondary animate-bounce" style={{ animationDelay: "0ms" }}></span>
                          <span className="w-2 h-2 rounded-full bg-secondary animate-bounce" style={{ animationDelay: "150ms" }}></span>
                          <span className="w-2 h-2 rounded-full bg-secondary animate-bounce" style={{ animationDelay: "300ms" }}></span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>

            {/* Message input */}
            <div className="flex-shrink-0 p-3 border-t border-border">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Plus className="h-5 w-5" />
                </Button>
                <Input
                  placeholder={`Message ${roomData.name}...`}
                  value={messageInput}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyDown}
                  className="rounded-full"
                />
                <Button
                  type="submit"
                  size="icon"
                  onClick={handleSendMessage}
                  disabled={messageInput.trim() === ""}
                  className="rounded-full"
                >
                  <Send className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>

          {/* Room sidebar */}
          <div className="hidden md:block w-64 border-l border-border bg-card overflow-y-auto">
            <div className="p-4">
              <h3 className="font-medium text-sm mb-3">Members ({roomData.members.length})</h3>
              <div className="space-y-2">
                {roomData.members.map((member) => (
                  <div key={member.id} className="flex items-center">
                    <div className={cn(
                      "h-2 w-2 rounded-full mr-2",
                      member.isOnline ? "bg-green-500" : "bg-gray-500"
                    )} />
                    <div className="text-sm">{member.name}</div>
                  </div>
                ))}
              </div>
              
              <Separator className="my-4" />
              
              <h3 className="font-medium text-sm mb-3">Room Settings</h3>
              <div className="space-y-2">
                <Button variant="ghost" size="sm" className="w-full justify-start">
                  <Settings className="h-4 w-4 mr-2" />
                  Manage Room
                </Button>
                <Button variant="ghost" size="sm" className="w-full justify-start">
                  <Users className="h-4 w-4 mr-2" />
                  Invite People
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}