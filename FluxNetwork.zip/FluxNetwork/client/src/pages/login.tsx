import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Separator } from "@/components/ui/separator";
import GoogleAuthButton from "@/components/auth/GoogleAuthButton";
import EmailAuthForm from "@/components/auth/EmailAuthForm";
import UsernamePasswordForm from "@/components/auth/UsernamePasswordForm";
import { handleRedirectResult } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function Login() {
  const { user, hasCompletedProfile, refreshUserProfile } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isHandlingRedirect, setIsHandlingRedirect] = useState(true);
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Handle redirect result from Google login
  useEffect(() => {
    const processRedirect = async () => {
      try {
        setIsHandlingRedirect(true);
        console.log("Processing redirect result from Google Auth...");
        
        const result = await handleRedirectResult();
        if (result?.user) {
          console.log("Successfully logged in via redirect", result.user.uid);
          
          // Make sure to refresh user profile data after successful login
          await refreshUserProfile();
          
          toast({
            title: "Login successful",
            description: "Welcome to Flux!",
          });
        } else {
          console.log("No redirect result found or already processed");
        }
      } catch (error) {
        // We shouldn't get here anymore since handleRedirectResult doesn't throw
        console.error("Error handling redirect:", error);
      } finally {
        setIsHandlingRedirect(false);
      }
    };

    processRedirect();
  }, [refreshUserProfile, toast]);

  // Check if we need to show the profile completion dialog
  useEffect(() => {
    if (user && !hasCompletedProfile) {
      setIsDialogOpen(true);
    } else {
      setIsDialogOpen(false);
    }
  }, [user, hasCompletedProfile]);
  
  // Redirect to dashboard if user is already authenticated and has completed profile
  useEffect(() => {
    if (!isHandlingRedirect && user && hasCompletedProfile) {
      // User is logged in and has completed their profile, redirect to dashboard
      navigate("/dashboard");
    }
  }, [user, hasCompletedProfile, isHandlingRedirect, navigate]);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow">
        <div className="flex flex-col items-center justify-center px-4 sm:px-6 lg:px-8 py-12 min-h-[calc(100vh-10rem)]">
          <div className="max-w-md w-full space-y-8">
            <div className="text-center">
              <h2 className="mt-6 text-3xl font-extrabold">Welcome to Flux</h2>
              <p className="mt-2 text-base text-muted-foreground">
                The modern platform for seamless communication
              </p>
            </div>

            <div className="mt-8 space-y-6 p-8 rounded-lg shadow-lg bg-card border border-border">
              <div className="space-y-4">
                <GoogleAuthButton />

                <div className="flex items-center my-4">
                  <Separator className="flex-grow" />
                  <span className="flex-shrink px-4 text-xs text-muted-foreground">OR</span>
                  <Separator className="flex-grow" />
                </div>

                <EmailAuthForm />
              </div>

              <div className="text-center text-xs text-muted-foreground">
                By continuing, you agree to Flux's{" "}
                <a href="#" className="text-primary hover:underline">
                  Terms of Service
                </a>{" "}
                and{" "}
                <a href="#" className="text-primary hover:underline">
                  Privacy Policy
                </a>
                .
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />

      {/* Complete Profile Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="flex gap-2 items-center">
              <i className="ri-user-add-line text-primary"></i>
              Complete Your Profile
            </DialogTitle>
            <DialogDescription>
              You're almost there! Just set up your username and password to continue.
            </DialogDescription>
          </DialogHeader>
          <UsernamePasswordForm />
        </DialogContent>
      </Dialog>
    </div>
  );
}
