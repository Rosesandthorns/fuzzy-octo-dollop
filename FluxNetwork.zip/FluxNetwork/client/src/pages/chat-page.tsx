import { useEffect, useState, useRef } from "react";
import { useLocation, useRoute } from "wouter";
import { AppLayout } from "@/components/layout/AppLayout";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Phone, Video, Info, Plus } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { useWebSocketContext } from "@/context/WebSocketContext";
import { useAuth } from "@/context/AuthContext";
import { webSocketManager } from "@/lib/websocket";

interface Message {
  id: string;
  content: string;
  timestamp: string;
  isCurrentUser: boolean;
}

export default function ChatPage() {
  const { toast } = useToast();
  const [match, params] = useRoute<{ id: string }>("/dashboard/chat/:id");
  const [, navigate] = useLocation();
  const [messageInput, setMessageInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { sendChatMessage, sendMessage, setTypingStatus, isConnected } = useWebSocketContext();
  const { user } = useAuth();
  
  // Redirect if no match
  useEffect(() => {
    if (!match) {
      navigate("/dashboard");
    }
  }, [match, navigate]);

  // Friend data loaded from Firestore
  const [friendData, setFriendData] = useState({
    id: params?.id || "",
    name: "Friend",
    status: "offline",
    avatar: undefined,
    lastSeen: "recently"
  });

  // Load friend data and set up WebSocket listeners
  useEffect(() => {
    // Initialize with empty messages
    setMessages([]);
    
    // If we have a friend ID, try to load their data
    if (params?.id) {
      const loadFriendData = async () => {
        try {
          // We would normally fetch the friend data from Firestore here
          // but for now, just set a placeholder with the ID
          setFriendData({
            id: params.id,
            name: `User ${params.id}`,
            status: "offline",
            avatar: undefined,
            lastSeen: "recently"
          });
        } catch (error) {
          console.error("Error loading friend data:", error);
          toast({
            title: "Error",
            description: "Could not load friend data.",
            variant: "destructive"
          });
        }
      };
      
      loadFriendData();
    }
    
    // Set up WebSocket listeners for real-time messaging
    const chatMessageHandler = (data: any) => {
      if (data.senderId === params?.id) {
        const newMessage: Message = {
          id: Date.now().toString(),
          content: data.message,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isCurrentUser: false
        };
        
        setMessages(prevMessages => [...prevMessages, newMessage]);
        
        // Auto-scroll to bottom
        if (scrollAreaRef.current) {
          setTimeout(() => {
            scrollAreaRef.current?.scrollTo({
              top: scrollAreaRef.current.scrollHeight,
              behavior: 'smooth'
            });
          }, 100);
        }
      }
    };
    
    const typingHandler = (data: any) => {
      if (data.senderId === params?.id) {
        setIsTyping(data.isTyping);
      }
    };
    
    // Register WebSocket listeners
    webSocketManager.on('chat_message', chatMessageHandler);
    webSocketManager.on('typing_indicator', typingHandler);
    
    // Clean up listeners on unmount
    return () => {
      webSocketManager.off('chat_message', chatMessageHandler);
      webSocketManager.off('typing_indicator', typingHandler);
    };
  }, [params?.id]);
  
  const handleSendMessage = () => {
    if (messageInput.trim() === "" || !isConnected) return;

    // Add the new message to local state
    const newMessage: Message = {
      id: Date.now().toString(),
      content: messageInput,
      timestamp: "Just now",
      isCurrentUser: true
    };

    setMessages([...messages, newMessage]);
    
    // Send message via WebSocket
    if (params?.id) {
      sendChatMessage(params.id, messageInput);
    }
    
    setMessageInput("");
    
    // Clear typing indicator
    if (params?.id) {
      setTypingStatus(params.id, false);
    }
    
    // Auto-scroll to bottom
    if (scrollAreaRef.current) {
      setTimeout(() => {
        scrollAreaRef.current?.scrollTo({
          top: scrollAreaRef.current.scrollHeight,
          behavior: 'smooth'
        });
      }, 100);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  // Handle input changes to send typing indicators
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessageInput(e.target.value);
    
    // Send typing indicator if a recipient is specified
    if (params?.id && isConnected) {
      setTypingStatus(params.id, e.target.value.length > 0);
    }
  };

  const handleCall = () => {
    toast({
      title: "Call Feature",
      description: "Voice call feature is coming soon!",
    });
  };

  const handleVideoCall = () => {
    toast({
      title: "Video Call Feature",
      description: "Video call feature is coming soon!",
    });
  };

  const handleInfo = () => {
    toast({
      title: "User Info",
      description: "User profile details coming soon!",
    });
  };

  if (!match) return null;

  return (
    <AppLayout>
      <div className="h-full flex flex-col">
        {/* Chat header */}
        <div className="flex-shrink-0 h-14 border-b border-border flex items-center justify-between px-4">
          <div className="flex items-center">
            <Avatar className="h-8 w-8 mr-3">
              <AvatarImage src={friendData.avatar} />
              <AvatarFallback className="bg-primary text-primary-foreground">
                {friendData.name.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-semibold text-sm">{friendData.name}</h2>
              <p className="text-xs text-muted-foreground">
                {friendData.status === "online" ? "Online" : `Last seen ${friendData.lastSeen}`}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <Button variant="ghost" size="icon" onClick={handleCall}>
              <Phone className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={handleVideoCall}>
              <Video className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={handleInfo}>
              <Info className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4" ref={scrollAreaRef as any}>
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={cn(
                "flex",
                message.isCurrentUser ? "justify-end" : "justify-start"
              )}>
                <div className={cn(
                  "max-w-[70%] rounded-lg p-3",
                  message.isCurrentUser
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted"
                )}>
                  <p className="text-sm">{message.content}</p>
                  <p className="text-xs opacity-70 mt-1 text-right">{message.timestamp}</p>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex items-center ml-2 mt-2">
                <div className="bg-muted rounded-full p-2 px-4">
                  <div className="flex items-center space-x-1">
                    <span className="w-2 h-2 rounded-full bg-secondary animate-bounce" style={{ animationDelay: "0ms" }}></span>
                    <span className="w-2 h-2 rounded-full bg-secondary animate-bounce" style={{ animationDelay: "150ms" }}></span>
                    <span className="w-2 h-2 rounded-full bg-secondary animate-bounce" style={{ animationDelay: "300ms" }}></span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Message input */}
        <div className="flex-shrink-0 p-3 border-t border-border">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="rounded-full">
              <Plus className="h-5 w-5" />
            </Button>
            <Input
              placeholder={`Message ${friendData.name}...`}
              value={messageInput}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              className="rounded-full"
            />
            <Button
              type="submit"
              size="icon"
              onClick={handleSendMessage}
              disabled={messageInput.trim() === ""}
              className="rounded-full"
            >
              <Send className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}