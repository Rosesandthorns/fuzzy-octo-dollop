import { PlaceholderPage } from "@/components/layout/PlaceholderPage";

export default function StatusPage() {
  return (
    <PlaceholderPage 
      title="System Status" 
      description="Check the current operational status of all Flux services and systems."
      category="Service"
    />
  );
}