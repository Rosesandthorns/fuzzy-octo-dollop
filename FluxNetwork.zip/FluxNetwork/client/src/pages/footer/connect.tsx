import { PlaceholderPage } from "@/components/layout/PlaceholderPage";

export default function ConnectPage() {
  return (
    <PlaceholderPage 
      title="Connect With Us" 
      description="Join our community and connect with the Flux team and other users."
      category="Community"
    />
  );
}