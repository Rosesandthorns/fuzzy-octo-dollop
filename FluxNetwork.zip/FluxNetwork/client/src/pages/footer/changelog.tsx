import { PlaceholderPage } from "@/components/layout/PlaceholderPage";

export default function ChangelogPage() {
  return (
    <PlaceholderPage 
      title="Changelog" 
      description="Stay up to date with all the latest improvements and updates to Flux."
      category="Product"
    />
  );
}