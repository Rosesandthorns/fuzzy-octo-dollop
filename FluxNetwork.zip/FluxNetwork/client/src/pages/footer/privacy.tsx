import { PlaceholderPage } from "@/components/layout/PlaceholderPage";

export default function PrivacyPage() {
  return (
    <PlaceholderPage 
      title="Privacy Policy" 
      description="Learn how we collect, use, and protect your personal information on Flux."
      category="Legal"
    />
  );
}