import { PlaceholderPage } from "@/components/layout/PlaceholderPage";

export default function ContactPage() {
  return (
    <PlaceholderPage 
      title="Contact Us" 
      description="Get in touch with our support team for any questions or assistance."
      category="Support"
    />
  );
}