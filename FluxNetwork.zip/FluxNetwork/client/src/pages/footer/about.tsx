import { PlaceholderPage } from "@/components/layout/PlaceholderPage";

export default function AboutPage() {
  return (
    <PlaceholderPage 
      title="About Flux" 
      description="Learn more about our mission, values, and the team behind Flux."
      category="Company"
    />
  );
}