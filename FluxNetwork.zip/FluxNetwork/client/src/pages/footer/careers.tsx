import { PlaceholderPage } from "@/components/layout/PlaceholderPage";

export default function CareersPage() {
  return (
    <PlaceholderPage 
      title="Careers at Flux" 
      description="Explore job opportunities and join our team in building the future of communication."
      category="Company"
    />
  );
}