import { PlaceholderPage } from "@/components/layout/PlaceholderPage";

export default function TermsPage() {
  return (
    <PlaceholderPage 
      title="Terms of Service" 
      description="Review the terms and conditions for using the Flux platform and services."
      category="Legal"
    />
  );
}