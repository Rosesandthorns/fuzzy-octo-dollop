import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { useTheme, ThemeColor, ThemeGradient, ThemeMode } from "@/context/ThemeContext";
import { useBlockedUsers } from "@/context/BlockedUsersContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { LockIcon, UnlockIcon, PlusIcon, TrashIcon, Paintbrush, Palette, MoonIcon, SunIcon, ComputerIcon, SwatchBook } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Helper function to convert hex to RGB
function hexToRgb(hex: string) {
  const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
  hex = hex.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b);
  
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
      }
    : null;
}

// Helper function for luminance calculation
function calculateLuminance(hex: string) {
  const rgb = hexToRgb(hex);
  if (!rgb) return 0;
  
  // Relative luminance calculation 
  // https://www.w3.org/TR/WCAG20/#relativeluminancedef
  const { r, g, b } = rgb;
  const a = [r, g, b].map(v => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2];
}

export default function SettingsPage() {
  const { theme, updateTheme, isColorRestricted, isGradientRestricted, availableColors, availableGradients, emojiSlotsAvailable, maxEmojiSlots } = useTheme();
  const { blockedUsers, unblockUser, isLoading: blockedUsersLoading } = useBlockedUsers();
  const { toast } = useToast();
  const [selectedEmoji, setSelectedEmoji] = useState<string | null>(null);

  const handleThemeModeChange = async (mode: ThemeMode) => {
    await updateTheme({ mode });
    toast({
      title: "Theme Updated",
      description: `Theme mode changed to ${mode}`
    });
  };

  const handleColorChange = async (color: ThemeColor) => {
    if (isColorRestricted(color)) {
      toast({
        title: "Upgrade Required",
        description: "This color is only available with the Glow tier or higher",
        variant: "destructive"
      });
      return;
    }
    
    await updateTheme({ color });
    toast({
      title: "Theme Updated",
      description: "Primary color changed successfully"
    });
  };

  const handleGradientChange = async (gradient: ThemeGradient) => {
    if (isGradientRestricted(gradient)) {
      toast({
        title: "Upgrade Required",
        description: "Gradients are only available with the Echo tier",
        variant: "destructive"
      });
      return;
    }
    
    await updateTheme({ gradient });
    toast({
      title: "Theme Updated",
      description: "Gradient theme applied successfully"
    });
  };

  const handleUnblockUser = async (userId: string) => {
    await unblockUser(userId);
    toast({
      title: "User Unblocked",
      description: "You've unblocked this user"
    });
  };

  const addEmoji = () => {
    if (theme.customEmojis.length >= maxEmojiSlots) {
      toast({
        title: "Emoji Limit Reached",
        description: `You can only add up to ${maxEmojiSlots} custom emojis with your current tier`,
        variant: "destructive"
      });
      return;
    }
    
    // Mock implementation - in a real app, this would open an emoji picker or file upload
    const newEmoji = "😊"; // This would come from user selection
    updateTheme({ 
      customEmojis: [...theme.customEmojis, newEmoji]
    });
    
    toast({
      title: "Emoji Added",
      description: "Custom emoji added successfully"
    });
  };

  const removeEmoji = (index: number) => {
    const updatedEmojis = [...theme.customEmojis];
    updatedEmojis.splice(index, 1);
    updateTheme({ customEmojis: updatedEmojis });
    
    toast({
      title: "Emoji Removed",
      description: "Custom emoji removed successfully"
    });
  };

  // Calculate text color based on background
  const getTextColor = (bgColor: string) => {
    const luminance = calculateLuminance(bgColor);
    return luminance > 0.5 ? "text-black" : "text-white";
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <h1 className="text-3xl font-bold">Settings</h1>
      
      <Tabs defaultValue="appearance">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="customization">Customization</TabsTrigger>
          <TabsTrigger value="blocked">Blocked Users</TabsTrigger>
          <TabsTrigger value="subscription">Subscription</TabsTrigger>
        </TabsList>
        
        {/* Appearance Tab */}
        <TabsContent value="appearance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5" />
                Theme
              </CardTitle>
              <CardDescription>
                Customize how Flux looks for you. Changes are saved automatically.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Theme Mode Selection */}
              <div>
                <h3 className="text-lg font-medium mb-3">Mode</h3>
                <RadioGroup 
                  value={theme.mode} 
                  onValueChange={(value) => handleThemeModeChange(value as ThemeMode)}
                  className="grid grid-cols-3 gap-4"
                >
                  <div>
                    <RadioGroupItem 
                      value="light" 
                      id="light" 
                      className="sr-only" 
                    />
                    <Label 
                      htmlFor="light"
                      className={`flex flex-col items-center justify-between rounded-md border-2 p-4 hover:border-primary cursor-pointer ${theme.mode === 'light' ? 'border-primary' : 'border-muted'}`}
                    >
                      <SunIcon className="mb-3 h-6 w-6" />
                      <span>Light</span>
                    </Label>
                  </div>
                  
                  <div>
                    <RadioGroupItem 
                      value="dark" 
                      id="dark" 
                      className="sr-only" 
                    />
                    <Label 
                      htmlFor="dark"
                      className={`flex flex-col items-center justify-between rounded-md border-2 p-4 hover:border-primary cursor-pointer ${theme.mode === 'dark' ? 'border-primary' : 'border-muted'}`}
                    >
                      <MoonIcon className="mb-3 h-6 w-6" />
                      <span>Dark</span>
                    </Label>
                  </div>
                  
                  <div>
                    <RadioGroupItem 
                      value="system" 
                      id="system" 
                      className="sr-only" 
                    />
                    <Label 
                      htmlFor="system"
                      className={`flex flex-col items-center justify-between rounded-md border-2 p-4 hover:border-primary cursor-pointer ${theme.mode === 'system' ? 'border-primary' : 'border-muted'}`}
                    >
                      <ComputerIcon className="mb-3 h-6 w-6" />
                      <span>System</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Color Selection */}
              <div>
                <h3 className="text-lg font-medium mb-3">Color</h3>
                <div className="grid grid-cols-5 md:grid-cols-10 gap-3">
                  {availableColors.map((color, index) => (
                    <div key={index} className="relative">
                      <button
                        className={`w-full aspect-square rounded-full ${
                          theme.color === color ? 'ring-2 ring-offset-2 ring-primary' : ''
                        } ${isColorRestricted(color) ? 'opacity-50' : ''}`}
                        style={{ backgroundColor: color }}
                        onClick={() => handleColorChange(color)}
                        disabled={isColorRestricted(color)}
                      >
                        <span className="sr-only">{color}</span>
                      </button>
                      {isColorRestricted(color) && (
                        <LockIcon className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Gradient Selection (Echo tier only) */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-lg font-medium flex items-center gap-2">
                    <SwatchBook className="h-5 w-5" />
                    Gradients
                    <Badge variant="outline" className={theme.tier === 'echo' ? 'bg-primary text-primary-foreground' : ''}>
                      Echo
                    </Badge>
                  </h3>
                </div>
                
                <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                  {availableGradients.slice(0, 10).map((gradient, index) => (
                    <div key={index} className="relative">
                      <button
                        className={`w-full h-16 rounded-md ${
                          theme.gradient?.from === gradient.from && theme.gradient?.to === gradient.to 
                            ? 'ring-2 ring-offset-2 ring-primary' 
                            : ''
                        } ${isGradientRestricted(gradient) ? 'opacity-50' : ''}`}
                        style={{ 
                          background: `linear-gradient(to ${gradient.direction.replace('to-', '')}, ${gradient.from}, ${gradient.to})` 
                        }}
                        onClick={() => handleGradientChange(gradient)}
                        disabled={isGradientRestricted(gradient)}
                      >
                        <span className="sr-only">Gradient {index + 1}</span>
                      </button>
                      {isGradientRestricted(gradient) && (
                        <LockIcon className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-5 w-5 text-white" />
                      )}
                    </div>
                  ))}
                </div>
                
                {isGradientRestricted(availableGradients[0]) && (
                  <p className="text-sm text-muted-foreground mt-2">
                    Upgrade to Echo tier to unlock gradient themes
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Customization Tab */}
        <TabsContent value="customization" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Paintbrush className="h-5 w-5" />
                Custom Emojis
              </CardTitle>
              <CardDescription>
                Add custom emojis to use across Flux. 
                {emojiSlotsAvailable} of {maxEmojiSlots} slots available.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">Your Emojis</h3>
                <div className="flex items-center space-x-1">
                  <span className="text-sm text-muted-foreground">
                    {theme.customEmojis.length}/{maxEmojiSlots}
                  </span>
                  <Button size="sm" onClick={addEmoji} disabled={theme.customEmojis.length >= maxEmojiSlots}>
                    <PlusIcon className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-8 md:grid-cols-10 gap-2">
                {theme.customEmojis.length > 0 ? (
                  theme.customEmojis.map((emoji, index) => (
                    <div key={index} className="relative group">
                      <div className="w-full aspect-square bg-muted rounded-md flex items-center justify-center text-2xl">
                        {emoji}
                      </div>
                      <button 
                        className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full p-0.5 hidden group-hover:flex"
                        onClick={() => removeEmoji(index)}
                      >
                        <TrashIcon className="h-3 w-3" />
                      </button>
                    </div>
                  ))
                ) : (
                  <div className="col-span-full text-center py-6 text-muted-foreground">
                    No custom emojis added yet. Click the Add button to get started.
                  </div>
                )}
              </div>
              
              <div className="mt-4">
                <h4 className="text-md font-medium mb-2">Emoji Slots by Tier</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>Basic</span>
                    <span>15 slots</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>Glow</span>
                      {theme.tier === 'basic' && <LockIcon className="h-3 w-3 text-muted-foreground" />}
                    </div>
                    <span>50 slots</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>Echo</span>
                      {theme.tier !== 'echo' && <LockIcon className="h-3 w-3 text-muted-foreground" />}
                    </div>
                    <span>150 slots</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Room Templates (Echo only) */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  Room Templates
                  <Badge variant="outline" className={theme.tier === 'echo' ? 'bg-primary text-primary-foreground' : ''}>
                    Echo
                  </Badge>
                </CardTitle>
              </div>
              <CardDescription>
                Create and save room templates for quick room creation.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {theme.tier === 'echo' ? (
                <div className="space-y-4">
                  <Button>
                    <PlusIcon className="h-4 w-4 mr-2" />
                    Create New Template
                  </Button>
                  
                  <div className="text-center py-6 text-muted-foreground">
                    No templates created yet. Create your first template to get started.
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 space-y-3">
                  <LockIcon className="h-10 w-10 text-muted-foreground" />
                  <p className="text-muted-foreground">Room templates are available with the Echo tier subscription</p>
                  <Button variant="outline">Upgrade to Echo</Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Blocked Users Tab */}
        <TabsContent value="blocked">
          <Card>
            <CardHeader>
              <CardTitle>Blocked Users</CardTitle>
              <CardDescription>
                Manage users you've blocked. Blocked users cannot message you or see your status.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {blockedUsersLoading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : blockedUsers.length > 0 ? (
                <div className="space-y-3">
                  {blockedUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarImage src={user.avatarUrl} />
                          <AvatarFallback>{user.displayName.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.displayName}</p>
                          <p className="text-sm text-muted-foreground">@{user.username}</p>
                        </div>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handleUnblockUser(user.id)}
                      >
                        <UnlockIcon className="h-4 w-4 mr-1" />
                        Unblock
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  You haven't blocked any users yet.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Subscription Tab */}
        <TabsContent value="subscription">
          <Card>
            <CardHeader>
              <CardTitle>Your Subscription</CardTitle>
              <CardDescription>
                Manage your Flux subscription and tier status.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-muted p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-semibold text-lg">Current Plan</h3>
                    <p className="text-xl font-bold capitalize">{theme.tier}</p>
                  </div>
                  <Badge className={
                    theme.tier === 'echo' ? 'bg-gradient-to-r from-purple-500 to-pink-500' :
                    theme.tier === 'glow' ? 'bg-primary' : 'bg-muted-foreground'
                  }>
                    {theme.tier === 'echo' ? 'Premium' : 
                    theme.tier === 'glow' ? 'Enhanced' : 'Free'}
                  </Badge>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Available Plans</h3>
                
                <div className="grid gap-4 grid-cols-1 md:grid-cols-3">
                  {/* Basic Plan */}
                  <div className={`border rounded-lg p-4 ${theme.tier === 'basic' ? 'border-primary' : ''}`}>
                    <div className="flex justify-between items-center">
                      <h4 className="font-bold text-lg">Basic</h4>
                      {theme.tier === 'basic' && <Badge>Current</Badge>}
                    </div>
                    <p className="text-2xl font-bold mt-2">Free</p>
                    <Separator className="my-4" />
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-white text-xs">✓</div>
                        <span>Light & Dark Mode</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-white text-xs">✓</div>
                        <span>10 Basic Colors</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-white text-xs">✓</div>
                        <span>15 Custom Emoji Slots</span>
                      </li>
                    </ul>
                    {theme.tier !== 'basic' && (
                      <Button variant="outline" className="w-full mt-4">Downgrade</Button>
                    )}
                  </div>
                  
                  {/* Glow Plan */}
                  <div className={`border rounded-lg p-4 ${theme.tier === 'glow' ? 'border-primary' : ''}`}>
                    <div className="flex justify-between items-center">
                      <h4 className="font-bold text-lg">Glow</h4>
                      {theme.tier === 'glow' && <Badge>Current</Badge>}
                    </div>
                    <p className="text-2xl font-bold mt-2">$5<span className="text-sm font-normal text-muted-foreground"> one-time</span></p>
                    <Separator className="my-4" />
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-white text-xs">✓</div>
                        <span>All Basic Features</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-white text-xs">✓</div>
                        <span>30+ Premium Colors</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-white text-xs">✓</div>
                        <span>50 Custom Emoji Slots</span>
                      </li>
                    </ul>
                    {theme.tier === 'basic' ? (
                      <Button className="w-full mt-4">Upgrade to Glow</Button>
                    ) : theme.tier === 'echo' ? (
                      <Button variant="outline" className="w-full mt-4">Downgrade</Button>
                    ) : (
                      <Button disabled className="w-full mt-4">Current Plan</Button>
                    )}
                  </div>
                  
                  {/* Echo Plan */}
                  <div className={`border rounded-lg p-4 ${theme.tier === 'echo' ? 'border-primary bg-gradient-to-r from-purple-500/5 to-pink-500/5' : ''}`}>
                    <div className="flex justify-between items-center">
                      <h4 className="font-bold text-lg">Echo</h4>
                      {theme.tier === 'echo' && <Badge className="bg-gradient-to-r from-purple-500 to-pink-500">Current</Badge>}
                    </div>
                    <p className="text-2xl font-bold mt-2">$5<span className="text-sm font-normal text-muted-foreground"> /month</span></p>
                    <Separator className="my-4" />
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-white text-xs">✓</div>
                        <span>All Glow Features</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-white text-xs">✓</div>
                        <span>25+ Premium Gradients</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-white text-xs">✓</div>
                        <span>150 Custom Emoji Slots</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-white text-xs">✓</div>
                        <span>Room Templates</span>
                      </li>
                    </ul>
                    {theme.tier !== 'echo' ? (
                      <Button className="w-full mt-4" variant={theme.tier === 'basic' ? "secondary" : "default"}>Upgrade to Echo</Button>
                    ) : (
                      <Button disabled className="w-full mt-4">Current Plan</Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}