import { createContext, ReactNode, useState, useEffect, useContext, useCallback } from "react";
import { useAuth } from "./AuthContext";
import { useToast } from "@/hooks/use-toast";
import { webSocketManager } from "@/lib/websocket";
import { User as FirebaseUser } from "firebase/auth";

interface WebSocketContextType {
  isConnected: boolean;
  sendMessage: (type: string, payload: any) => boolean;
  sendChatMessage: (recipientId: string, message: string) => boolean;
  sendRoomMessage: (roomId: string, message: string) => boolean;
  setTypingStatus: (recipientId: string, isTyping: boolean, isRoom?: boolean) => boolean;
}

const WebSocketContext = createContext<WebSocketContextType | null>(null);

export function useWebSocketContext() {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error("useWebSocketContext must be used within a WebSocketProvider");
  }
  return context;
}

interface WebSocketProviderProps {
  children: ReactNode;
}

export function WebSocketProvider({ children }: WebSocketProviderProps) {
  const [isConnected, setIsConnected] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  // Initialize connection
  useEffect(() => {
    if (!user || !user.uid) return;

    // Setup connection status listener
    const connectionListener = (data: any) => {
      setIsConnected(data.status === 'connected');
      
      // If connected, set user status
      if (data.status === 'connected' && user) {
        webSocketManager.send('user_status', {
          userId: user.uid,
          status: 'online'
        });
      }
    };

    // Setup message listeners
    const messageListener = (data: any) => {
      // We could add global message handling here if needed
      console.log('Received WebSocket message:', data);
    };

    // Setup chat message listener
    const chatMessageListener = (data: any) => {
      // Show a notification for new messages when not actively viewing the chat
      const currentPath = window.location.pathname;
      const isChatActive = currentPath.includes('/dashboard/chat/') && 
                          currentPath.includes(data.senderId);
      
      if (!isChatActive) {
        toast({
          title: "New Message",
          description: `You received a new message!`,
        });
      }
    };
    
    // Setup room message listener
    const roomMessageListener = (data: any) => {
      // Show a notification for new room messages when not actively viewing the room
      const currentPath = window.location.pathname;
      const isRoomActive = currentPath.includes('/dashboard/room/') && 
                          currentPath.includes(data.roomId);
      
      if (!isRoomActive) {
        toast({
          title: "New Room Message",
          description: `New message in ${data.roomId}`,
        });
      }
    };

    // Register listeners
    webSocketManager.on('connection', connectionListener);
    webSocketManager.on('message', messageListener);
    webSocketManager.on('chat_message', chatMessageListener);
    webSocketManager.on('room_message', roomMessageListener);

    // Connect to WebSocket server
    webSocketManager.connect();

    // Cleanup on unmount
    return () => {
      webSocketManager.off('connection', connectionListener);
      webSocketManager.off('message', messageListener);
      webSocketManager.off('chat_message', chatMessageListener);
      webSocketManager.off('room_message', roomMessageListener);
      webSocketManager.disconnect();
    };
  }, [user, toast]);

  // Send a generic message
  const sendMessage = useCallback((type: string, payload: any) => {
    return webSocketManager.send(type, payload);
  }, []);

  // Send a chat message to a specific user
  const sendChatMessage = useCallback((recipientId: string, message: string) => {
    if (!user?.uid) return false;
    
    return webSocketManager.send('chat_message', {
      senderId: user.uid,
      senderName: user.displayName || 'User',
      recipientId,
      message
    });
  }, [user]);

  // Send a message to a room
  const sendRoomMessage = useCallback((roomId: string, message: string) => {
    if (!user?.uid) return false;
    
    return webSocketManager.send('room_message', {
      senderId: user.uid,
      senderName: user.displayName || 'User',
      roomId,
      message
    });
  }, [user]);

  // Send typing indicator
  const setTypingStatus = useCallback((recipientId: string, isTyping: boolean, isRoom: boolean = false) => {
    if (!user?.uid) return false;
    
    if (isRoom) {
      // For room typing indicators
      return webSocketManager.send('typing_indicator', {
        senderId: user.uid,
        senderName: user.displayName || 'User',
        roomId: recipientId,
        isTyping,
        isRoom: true
      });
    } else {
      // For direct messages typing indicators
      return webSocketManager.send('typing_indicator', {
        senderId: user.uid,
        recipientId,
        isTyping,
        isRoom: false
      });
    }
  }, [user]);

  // Context value
  const value = {
    isConnected,
    sendMessage,
    sendChatMessage,
    sendRoomMessage,
    setTypingStatus
  };

  return (
    <WebSocketContext.Provider value={value}>
      {children}
    </WebSocketContext.Provider>
  );
}