import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { db } from "@/lib/firebase";
import { doc, getDoc, setDoc, updateDoc, arrayUnion, arrayRemove } from "firebase/firestore";
import { useAuth } from "./AuthContext";

interface BlockedUser {
  id: string;
  username: string;
  displayName: string;
  avatarUrl?: string;
  blockedAt: Date;
}

interface BlockedUsersContextType {
  blockedUsers: BlockedUser[];
  isUserBlocked: (userId: string) => boolean;
  blockUser: (userId: string, userData: Omit<BlockedUser, 'blockedAt'>) => Promise<void>;
  unblockUser: (userId: string) => Promise<void>;
  isLoading: boolean;
}

const BlockedUsersContext = createContext<BlockedUsersContextType>({
  blockedUsers: [],
  isUserBlocked: () => false,
  blockUser: async () => {},
  unblockUser: async () => {},
  isLoading: false,
});

export const useBlockedUsers = () => useContext(BlockedUsersContext);

interface BlockedUsersProviderProps {
  children: ReactNode;
}

export const BlockedUsersProvider = ({ children }: BlockedUsersProviderProps) => {
  const { user } = useAuth();
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Load blocked users from Firestore when user changes
  useEffect(() => {
    const loadBlockedUsers = async () => {
      if (!user) {
        setBlockedUsers([]);
        setIsLoading(false);
        return;
      }
      
      setIsLoading(true);
      
      try {
        const blockedUsersRef = doc(db, "users", user.uid, "settings", "blockedUsers");
        const blockedUsersDoc = await getDoc(blockedUsersRef);
        
        if (blockedUsersDoc.exists()) {
          setBlockedUsers(blockedUsersDoc.data().users || []);
        } else {
          // Initialize with empty array
          await setDoc(blockedUsersRef, { users: [] });
          setBlockedUsers([]);
        }
      } catch (error) {
        console.error("Error loading blocked users:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadBlockedUsers();
  }, [user]);

  // Check if a user is blocked
  const isUserBlocked = (userId: string) => {
    return blockedUsers.some(blockedUser => blockedUser.id === userId);
  };

  // Block a user
  const blockUser = async (userId: string, userData: Omit<BlockedUser, 'blockedAt'>) => {
    if (!user) return;
    
    const newBlockedUser: BlockedUser = {
      ...userData,
      id: userId,
      blockedAt: new Date(),
    };
    
    try {
      // Update local state
      setBlockedUsers([...blockedUsers, newBlockedUser]);
      
      // Update Firestore
      const blockedUsersRef = doc(db, "users", user.uid, "settings", "blockedUsers");
      await updateDoc(blockedUsersRef, {
        users: arrayUnion(newBlockedUser)
      });
    } catch (error) {
      console.error("Error blocking user:", error);
      // If document doesn't exist yet, create it
      try {
        const blockedUsersRef = doc(db, "users", user.uid, "settings", "blockedUsers");
        await setDoc(blockedUsersRef, {
          users: [newBlockedUser],
        });
      } catch (setError) {
        console.error("Error creating blocked users document:", setError);
      }
    }
  };

  // Unblock a user
  const unblockUser = async (userId: string) => {
    if (!user) return;
    
    try {
      // Find the user to remove
      const userToUnblock = blockedUsers.find(bu => bu.id === userId);
      if (!userToUnblock) return;
      
      // Update local state
      setBlockedUsers(blockedUsers.filter(bu => bu.id !== userId));
      
      // Update Firestore
      const blockedUsersRef = doc(db, "users", user.uid, "settings", "blockedUsers");
      await updateDoc(blockedUsersRef, {
        users: arrayRemove(userToUnblock)
      });
    } catch (error) {
      console.error("Error unblocking user:", error);
    }
  };

  const value = {
    blockedUsers,
    isUserBlocked,
    blockUser,
    unblockUser,
    isLoading,
  };

  return <BlockedUsersContext.Provider value={value}>{children}</BlockedUsersContext.Provider>;
};