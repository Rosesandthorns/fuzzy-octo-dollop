import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { onAuthChange, getCurrentUser, checkUserProfile } from "@/lib/auth";
import { User as FirebaseUser } from "firebase/auth";
import { User } from "@shared/schema";

interface AuthContextType {
  user: FirebaseUser | null;
  loading: boolean;
  userProfile: User | null;
  hasCompletedProfile: boolean;
  refreshUserProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  userProfile: null,
  hasCompletedProfile: false,
  refreshUserProfile: async () => {},
});

export const useAuth = () => useContext(AuthContext);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchUserProfile = async (uid: string) => {
    try {
      const profile = await checkUserProfile(uid);
      setUserProfile(profile);
      return profile;
    } catch (error) {
      console.error("Error fetching user profile:", error);
      return null;
    }
  };

  const refreshUserProfile = async () => {
    const currentUser = getCurrentUser();
    if (currentUser?.uid) {
      await fetchUserProfile(currentUser.uid);
    }
  };

  useEffect(() => {
    console.log("Setting up Firebase auth state listener");
    
    const unsubscribe = onAuthChange(async (firebaseUser) => {
      console.log("Auth state changed:", firebaseUser ? "User authenticated" : "No user");
      setUser(firebaseUser);
      
      if (firebaseUser?.uid) {
        console.log("Fetching user profile for", firebaseUser.uid);
        try {
          const profile = await fetchUserProfile(firebaseUser.uid);
          console.log("Profile status:", profile ? "Found" : "Not found");
        } catch (error) {
          console.error("Error fetching user profile:", error);
        }
      } else {
        console.log("No authenticated user, clearing profile data");
        setUserProfile(null);
      }
      
      setLoading(false);
    });

    // Initialize with current user if already authenticated
    const currentUser = getCurrentUser();
    if (currentUser) {
      console.log("Found already authenticated user on initialization");
      refreshUserProfile();
    } else {
      console.log("No user found during initialization");
      setLoading(false);
    }

    return () => {
      console.log("Cleaning up auth state listener");
      unsubscribe();
    };
  }, []);

  const value = {
    user,
    loading,
    userProfile,
    hasCompletedProfile: !!userProfile,
    refreshUserProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
