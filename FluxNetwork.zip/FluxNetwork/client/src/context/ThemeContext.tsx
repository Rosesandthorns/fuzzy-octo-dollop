import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { db } from "@/lib/firebase";
import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { useAuth } from "./AuthContext";

// Theme types
export type ThemeMode = "light" | "dark" | "system";
export type ThemeColor = string; // hex color
export type ThemeGradient = {
  from: string;
  to: string;
  direction: "to-r" | "to-t" | "to-tr" | "to-br" | "to-b" | "to-bl" | "to-l" | "to-tl";
};

export type ThemeTier = "basic" | "glow" | "echo";

export interface ThemeSettings {
  mode: ThemeMode;
  color: ThemeColor;
  gradient?: ThemeGradient;
  customEmojis: string[];
  tier: ThemeTier;
}

interface ThemeContextType {
  theme: ThemeSettings;
  updateTheme: (settings: Partial<ThemeSettings>) => Promise<void>;
  isColorRestricted: (color: ThemeColor) => boolean;
  isGradientRestricted: (gradient: ThemeGradient) => boolean;
  availableColors: ThemeColor[];
  availableGradients: ThemeGradient[];
  emojiSlotsAvailable: number;
  maxEmojiSlots: number;
}

const defaultTheme: ThemeSettings = {
  mode: "system",
  color: "#7C3AED", // Default purple color
  customEmojis: [],
  tier: "basic"
};

const basicColors = [
  "#000000", // Black
  "#FFFFFF", // White 
  "#4B5563", // Gray
  "#7C3AED", // Purple (default theme)
];

const glowColors = [
  // Basic Colors
  "#EF4444", // Red
  "#F59E0B", // Amber
  "#10B981", // Emerald
  "#3B82F6", // Blue
  "#6366F1", // Indigo
  "#8B5CF6", // Violet
  "#EC4899", // Pink
  
  // Vibrant Colors
  "#FF6B6B", // Coral Red
  "#4ECDC4", // Medium Turquoise  
  "#FF9F1C", // Orange Peel
  "#F72585", // Flickr Pink
  "#4CC9F0", // Vivid Sky Blue
  "#7209B7", // Purple
  "#480CA8", // Indigo
  "#4361EE", // Ultramarine Blue
  "#3A0CA3", // Persian Blue
  "#4895EF", // Cornflower Blue
  "#98F5E1", // Aquamarine
  "#FFFBBD", // Light Yellow
  "#B9FBC0", // Light Mint
  "#F1C0E8", // Pink Lace
  "#CFBAF0", // Lavender
  "#A3C4F3", // Light Steel Blue
  "#90DBF4", // Light Sky Blue
  "#8EECF5", // Light Cyan
  "#FB8500", // Orange
  "#FBF8CC", // Cream
  "#FDE4CF", // Champagne
  "#FFCFD2", // Light Pink
  "#FF4D6D", // Bright Pink
];

const echoGradients = [
  // Cool gradients
  { from: "#4158D0", to: "#C850C0", direction: "to-r" as const },
  { from: "#0093E9", to: "#80D0C7", direction: "to-r" as const },
  { from: "#8EC5FC", to: "#E0C3FC", direction: "to-r" as const },
  { from: "#D9AFD9", to: "#97D9E1", direction: "to-r" as const },
  { from: "#00DBDE", to: "#FC00FF", direction: "to-r" as const },
  { from: "#0250c5", to: "#d43f8d", direction: "to-r" as const },
  { from: "#f77062", to: "#fe5196", direction: "to-r" as const },
  { from: "#8E2DE2", to: "#4A00E0", direction: "to-r" as const },
  { from: "#FF3CAC", to: "#784BA0", direction: "to-r" as const },
  { from: "#F761A1", to: "#8C1BAB", direction: "to-r" as const },
  { from: "#43CBFF", to: "#9708CC", direction: "to-r" as const },
  { from: "#4158D0", to: "#C850C0", direction: "to-r" as const },
  { from: "#ff0844", to: "#ffb199", direction: "to-br" as const },
  { from: "#fd1d1d", to: "#833ab4", direction: "to-tr" as const },
  { from: "#30cfd0", to: "#330867", direction: "to-b" as const },
  { from: "#f5f7fa", to: "#c3cfe2", direction: "to-b" as const },
  { from: "#48c6ef", to: "#6f86d6", direction: "to-br" as const },
  { from: "#feada6", to: "#f5efef", direction: "to-br" as const },
  { from: "#A1C4FD", to: "#C2E9FB", direction: "to-tr" as const },
  { from: "#fa709a", to: "#fee140", direction: "to-tr" as const },
  { from: "#667eea", to: "#764ba2", direction: "to-tr" as const },
  { from: "#ff9a9e", to: "#fad0c4", direction: "to-t" as const },
  { from: "#5ee7df", to: "#b490ca", direction: "to-tr" as const },
  { from: "#d299c2", to: "#fef9d7", direction: "to-tr" as const },
  { from: "#6a11cb", to: "#2575fc", direction: "to-r" as const },
];

// Define emoji slots per tier
const emojiSlots = {
  basic: 15,
  glow: 50,
  echo: 150
};

const ThemeContext = createContext<ThemeContextType>({
  theme: defaultTheme,
  updateTheme: async () => {},
  isColorRestricted: () => true,
  isGradientRestricted: () => true,
  availableColors: [...basicColors],
  availableGradients: [],
  emojiSlotsAvailable: emojiSlots.basic,
  maxEmojiSlots: emojiSlots.basic
});

export const useTheme = () => useContext(ThemeContext);

interface ThemeProviderProps {
  children: ReactNode;
}

export const ThemeProvider = ({ children }: ThemeProviderProps) => {
  const { user } = useAuth();
  const [theme, setTheme] = useState<ThemeSettings>(defaultTheme);

  // Load theme from localStorage or Firestore when user changes
  useEffect(() => {
    const loadTheme = async () => {
      // First try localStorage for offline/instant access
      const savedTheme = localStorage.getItem("flux_theme");
      if (savedTheme) {
        try {
          const parsedTheme = JSON.parse(savedTheme) as ThemeSettings;
          setTheme(parsedTheme);
        } catch (error) {
          console.error("Error parsing saved theme:", error);
        }
      }

      // If user is logged in, fetch from Firestore
      if (user) {
        try {
          const userThemeRef = doc(db, "users", user.uid, "settings", "theme");
          const themeDoc = await getDoc(userThemeRef);
          
          if (themeDoc.exists()) {
            const firestoreTheme = themeDoc.data() as ThemeSettings;
            setTheme(firestoreTheme);
            
            // Update localStorage with latest from Firestore
            localStorage.setItem("flux_theme", JSON.stringify(firestoreTheme));
          } else {
            // Create default theme in Firestore
            await setDoc(userThemeRef, defaultTheme);
          }
        } catch (error) {
          console.error("Error loading theme from Firestore:", error);
        }
      }
    };

    loadTheme();
  }, [user]);

  // Apply theme to HTML element when theme changes
  useEffect(() => {
    const htmlElement = document.documentElement;
    
    // Apply dark/light mode
    if (theme.mode === "system") {
      const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      htmlElement.classList.toggle("dark", prefersDark);
    } else {
      htmlElement.classList.toggle("dark", theme.mode === "dark");
    }
    
    // Apply theme color
    const colorVariable = "--theme-primary";
    htmlElement.style.setProperty(colorVariable, theme.color);
    
    // Apply gradient if available
    if (theme.gradient && theme.tier === "echo") {
      htmlElement.style.setProperty("--gradient-from", theme.gradient.from);
      htmlElement.style.setProperty("--gradient-to", theme.gradient.to);
      htmlElement.style.setProperty("--gradient-direction", theme.gradient.direction);
      htmlElement.dataset.gradient = "true";
    } else {
      htmlElement.dataset.gradient = "false";
    }
  }, [theme]);

  // Update theme function
  const updateTheme = async (newSettings: Partial<ThemeSettings>) => {
    const updatedTheme = { ...theme, ...newSettings };
    
    // Update local state
    setTheme(updatedTheme);
    
    // Save to localStorage
    localStorage.setItem("flux_theme", JSON.stringify(updatedTheme));
    
    // Save to Firestore if user is logged in
    if (user) {
      try {
        const userThemeRef = doc(db, "users", user.uid, "settings", "theme");
        await updateDoc(userThemeRef, updatedTheme);
      } catch (error) {
        console.error("Error saving theme to Firestore:", error);
        // If document doesn't exist yet, create it
        try {
          const userThemeRef = doc(db, "users", user.uid, "settings", "theme");
          await setDoc(userThemeRef, updatedTheme);
        } catch (setError) {
          console.error("Error creating theme document:", setError);
        }
      }
    }
  };

  // Check if a color is restricted based on user's tier
  const isColorRestricted = (color: ThemeColor) => {
    if (theme.tier === "echo" || theme.tier === "glow") {
      return false; // Echo and Glow tiers have access to all colors
    }
    
    // Basic tier only has access to basicColors
    return !basicColors.includes(color);
  };

  // Check if a gradient is restricted
  const isGradientRestricted = (gradient: ThemeGradient) => {
    return theme.tier !== "echo";  // Only Echo tier has access to gradients
  };
  
  // Get available colors based on user's tier
  const getAvailableColors = () => {
    if (theme.tier === "echo" || theme.tier === "glow") {
      return [...basicColors, ...glowColors];
    }
    return [...basicColors];
  };

  // Get max emoji slots based on user's tier
  const getMaxEmojiSlots = () => {
    return emojiSlots[theme.tier];
  };
  
  // Get remaining emoji slots
  const getEmojiSlotsAvailable = () => {
    const maxSlots = getMaxEmojiSlots();
    const usedSlots = theme.customEmojis.length;
    return maxSlots - usedSlots;
  };

  const value = {
    theme,
    updateTheme,
    isColorRestricted,
    isGradientRestricted,
    availableColors: getAvailableColors(),
    availableGradients: echoGradients,
    emojiSlotsAvailable: getEmojiSlotsAvailable(),
    maxEmojiSlots: getMaxEmojiSlots()
  };

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};