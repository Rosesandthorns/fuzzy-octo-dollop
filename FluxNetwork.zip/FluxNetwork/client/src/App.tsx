import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Features from "@/pages/features";
import Pricing from "@/pages/pricing";
import Support from "@/pages/support";
// Dashboard pages
import RoomPage from "@/pages/room-page";
import ChatPage from "@/pages/chat-page";
import MessagesPage from "@/pages/messages-page";
import FriendsPage from "@/pages/friends-page";
import AccountPage from "@/pages/account-page";
import AddFriendPage from "@/pages/add-friend-page";
import CreateRoomPage from "@/pages/create-room-page";
import SettingsPage from "@/pages/settings-page";
// Footer pages
import About from "@/pages/footer/about";
import Connect from "@/pages/footer/connect";
import Contact from "@/pages/footer/contact";
import Privacy from "@/pages/footer/privacy";
import Status from "@/pages/footer/status";
import Terms from "@/pages/footer/terms";
import Careers from "@/pages/footer/careers";
import Changelog from "@/pages/footer/changelog";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { WebSocketProvider } from "./context/WebSocketContext";
import { ThemeProvider } from "./context/ThemeContext";
import { BlockedUsersProvider } from "./context/BlockedUsersContext";
import { useEffect } from "react";
import { handleRedirectResult } from "./lib/auth";

function Router() {
  const [location, setLocation] = useLocation();
  const { user, loading, hasCompletedProfile, refreshUserProfile } = useAuth();
  
  // Handle Google sign-in redirect result
  useEffect(() => {
    const processRedirectResult = async () => {
      try {
        const result = await handleRedirectResult();
        if (result && result.user) {
          // After handling redirect, refresh the user profile
          await refreshUserProfile();
        }
      } catch (error) {
        console.error("Error processing redirect:", error);
      }
    };
    
    processRedirectResult();
  }, [refreshUserProfile]);

  // Redirect based on auth state
  useEffect(() => {
    // Don't redirect while still loading authentication state
    if (loading) {
      console.log("Auth state loading, skipping redirect logic");
      return;
    }

    // Allow access to public pages without authentication
    const publicPaths = [
      "/", "/features", "/pricing", "/support", "/login",
      "/about", "/connect", "/contact", "/privacy", 
      "/status", "/terms", "/careers", "/changelog"
    ];
    
    // Check if current location is a dashboard path
    const isDashboardPath = location === "/dashboard" || 
      location.startsWith("/dashboard/");
      
    const isPublicPath = publicPaths.some(path => location === path || location.startsWith(path + "/"));

    console.log("Auth state:", { 
      user: !!user, 
      hasCompletedProfile, 
      isPublicPath, 
      isDashboardPath, 
      location 
    });

    // User not logged in, accessing protected route - redirect to login
    if (!user && !isPublicPath) {
      console.log("User not authenticated, redirecting to login");
      setLocation("/login");
    } 
    // User logged in but profile not completed
    else if (user && !hasCompletedProfile && location !== "/login") {
      console.log("User authenticated but profile incomplete, redirecting to login for profile completion");
      setLocation("/login");
    } 
    // User authenticated with complete profile, on login page - redirect to dashboard
    else if (user && hasCompletedProfile && location === "/login") {
      console.log("User authenticated with complete profile, redirecting to dashboard");
      setLocation("/dashboard");
    }
  }, [user, loading, location, hasCompletedProfile, setLocation]);

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/features" component={Features} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/support" component={Support} />
      
      {/* Dashboard Pages */}
      <Route path="/dashboard/room/:id" component={RoomPage} />
      <Route path="/dashboard/chat/:id" component={ChatPage} />
      <Route path="/dashboard/messages" component={MessagesPage} />
      <Route path="/dashboard/friends" component={FriendsPage} />
      <Route path="/dashboard/account" component={AccountPage} />
      <Route path="/dashboard/add-friend" component={AddFriendPage} />
      <Route path="/dashboard/create-room" component={CreateRoomPage} />
      <Route path="/dashboard/settings" component={SettingsPage} />
      
      {/* Footer Pages */}
      <Route path="/about" component={About} />
      <Route path="/connect" component={Connect} />
      <Route path="/contact" component={Contact} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/status" component={Status} />
      <Route path="/terms" component={Terms} />
      <Route path="/careers" component={Careers} />
      <Route path="/changelog" component={Changelog} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ThemeProvider>
          <BlockedUsersProvider>
            <WebSocketProvider>
              <Router />
              <Toaster />
            </WebSocketProvider>
          </BlockedUsersProvider>
        </ThemeProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
