import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertUserSchema, userProfileSchema } from "@shared/schema";
import { z } from "zod";

// WebSocket message types
type MessageType = 
  | 'chat_message'
  | 'room_message'
  | 'friend_request'
  | 'user_status'
  | 'typing_indicator'
  | 'read_receipt'
  | 'connection';

interface WSMessage {
  type: MessageType;
  payload: any;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok" });
  });

  // User routes
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid user data", error: error.format() });
      } else if (error instanceof Error) {
        res.status(500).json({ message: "Failed to create user", error: error.message });
      } else {
        res.status(500).json({ message: "An unknown error occurred" });
      }
    }
  });

  app.get("/api/users/check-username/:username", async (req: Request, res: Response) => {
    try {
      const { username } = req.params;
      if (!username || username.length < 3) {
        return res.status(400).json({ available: false, message: "Username too short" });
      }
      
      const existingUser = await storage.getUserByUsername(username);
      res.json({ available: !existingUser });
    } catch (error) {
      res.status(500).json({ available: false, message: "Error checking username" });
    }
  });

  app.get("/api/users/firebase/:firebaseUid", async (req: Request, res: Response) => {
    try {
      const { firebaseUid } = req.params;
      const user = await storage.getUserByFirebaseUid(firebaseUid);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      if (error instanceof Error) {
        res.status(500).json({ message: "Failed to get user", error: error.message });
      } else {
        res.status(500).json({ message: "An unknown error occurred" });
      }
    }
  });

  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const user = await storage.getUser(parseInt(id));
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      if (error instanceof Error) {
        res.status(500).json({ message: "Failed to get user", error: error.message });
      } else {
        res.status(500).json({ message: "An unknown error occurred" });
      }
    }
  });

  // Initialize HTTP server
  const httpServer = createServer(app);
  
  // Setup WebSocket Server on a distinct path
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Map to store connected clients
  const clients: Map<string, { ws: WebSocket, userId: string | null }> = new Map();
  
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    // Generate a temporary ID until user authenticates
    const clientId = Date.now().toString();
    clients.set(clientId, { ws, userId: null });
    
    // Send welcome message
    ws.send(JSON.stringify({
      type: 'connection',
      payload: { status: 'connected', message: 'Welcome to Flux!' }
    }));
    
    // Handle messages
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString()) as WSMessage;
        console.log('Received:', data.type);
        
        // Handle different message types
        switch (data.type) {
          case 'chat_message':
            handleChatMessage(clientId, data.payload);
            break;
            
          case 'room_message':
            handleRoomMessage(clientId, data.payload);
            break;
            
          case 'user_status':
            handleUserStatus(clientId, data.payload);
            break;
            
          case 'typing_indicator':
            handleTypingIndicator(clientId, data.payload);
            break;
            
          default:
            console.log('Unknown message type:', data.type);
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    });
    
    // Handle disconnect
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      
      // Get client info
      const client = clients.get(clientId);
      
      // If user was authenticated, notify others of status change
      if (client && client.userId) {
        broadcastUserStatus(client.userId, 'offline');
      }
      
      // Remove client from map
      clients.delete(clientId);
    });
  });
  
  // Helper functions for WebSocket message handling
  function handleChatMessage(clientId: string, payload: any) {
    const { recipientId, message } = payload;
    const client = clients.get(clientId);
    
    if (!client || !client.userId) {
      return; // Client not authenticated
    }
    
    // Find recipient's connection if online
    clients.forEach((c, id) => {
      if (c.userId === recipientId && c.ws.readyState === WebSocket.OPEN) {
        c.ws.send(JSON.stringify({
          type: 'chat_message',
          payload: {
            senderId: client.userId,
            message,
            timestamp: new Date().toISOString()
          }
        }));
      }
    });
  }
  
  function handleRoomMessage(clientId: string, payload: any) {
    const { roomId, message } = payload;
    const client = clients.get(clientId);
    
    if (!client || !client.userId) {
      return; // Client not authenticated
    }
    
    // Broadcast to all users in the room
    clients.forEach((c, id) => {
      if (id !== clientId && c.ws.readyState === WebSocket.OPEN) {
        // In a real app, we would check if this user is in the room
        c.ws.send(JSON.stringify({
          type: 'room_message',
          payload: {
            roomId,
            senderId: client.userId,
            message,
            timestamp: new Date().toISOString()
          }
        }));
      }
    });
  }
  
  function handleUserStatus(clientId: string, payload: any) {
    const { userId, status } = payload;
    const client = clients.get(clientId);
    
    // Update client's user ID if authenticating
    if (client && userId) {
      client.userId = userId;
    }
    
    // Broadcast status to other users
    broadcastUserStatus(userId, status);
  }
  
  function handleTypingIndicator(clientId: string, payload: any) {
    const { recipientId, roomId, isTyping, isRoom } = payload;
    const client = clients.get(clientId);
    
    if (!client || !client.userId) {
      return; // Client not authenticated
    }
    
    if (isRoom) {
      // Room typing indicator - broadcast to everyone in the room
      clients.forEach((c, id) => {
        if (id !== clientId && c.ws.readyState === WebSocket.OPEN) {
          // In a real app, we would check if this user is in the room
          c.ws.send(JSON.stringify({
            type: 'typing_indicator',
            payload: {
              roomId,
              senderId: client.userId,
              senderName: payload.senderName || 'User',
              isTyping,
              isRoom: true
            }
          }));
        }
      });
    } else {
      // Direct message typing indicator - send only to recipient
      clients.forEach((c, id) => {
        if (c.userId === recipientId && c.ws.readyState === WebSocket.OPEN) {
          c.ws.send(JSON.stringify({
            type: 'typing_indicator',
            payload: {
              senderId: client.userId,
              isTyping,
              isRoom: false
            }
          }));
        }
      });
    }
  }
  
  function broadcastUserStatus(userId: string, status: string) {
    // Broadcast to all connected clients
    clients.forEach((client, id) => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify({
          type: 'user_status',
          payload: {
            userId,
            status,
            timestamp: new Date().toISOString()
          }
        }));
      }
    });
  }

  return httpServer;
}
