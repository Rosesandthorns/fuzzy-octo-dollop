import { users, type User, type InsertUser, messages, type Message, type InsertMessage } from "@shared/schema";

// User storage interface with all needed methods
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getMessage(id: number): Promise<Message | undefined>;
  getMessagesBySenderId(senderId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private messages: Map<number, Message>;
  private userIdCounter: number;
  private messageIdCounter: number;

  constructor() {
    this.users = new Map();
    this.messages = new Map();
    this.userIdCounter = 1;
    this.messageIdCounter = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.firebaseUid === firebaseUid
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Check if username already exists
    const existingUser = await this.getUserByUsername(insertUser.username);
    if (existingUser) {
      throw new Error("Username already exists");
    }

    // Check if Firebase UID already exists
    if (insertUser.firebaseUid) {
      const existingFirebaseUser = await this.getUserByFirebaseUid(insertUser.firebaseUid);
      if (existingFirebaseUser) {
        throw new Error("User with this Firebase UID already exists");
      }
    }

    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: now,
      lastLogin: now
    };
    
    this.users.set(id, user);
    return user;
  }

  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async getMessagesBySenderId(senderId: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (message) => message.senderId === senderId
    );
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    // Verify sender exists
    const sender = await this.getUser(insertMessage.senderId);
    if (!sender) {
      throw new Error("Sender does not exist");
    }

    const id = this.messageIdCounter++;
    const now = new Date();
    const message: Message = {
      ...insertMessage,
      id,
      createdAt: now,
      isRead: false
    };

    this.messages.set(id, message);
    return message;
  }
}

export const storage = new MemStorage();
